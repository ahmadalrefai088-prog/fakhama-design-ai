export type ActiveTab =
  | 'home'
  | 'generator'
  | 'templates'
  | 'editor'
  | 'copywriter'
  | 'logo'
  | 'video'
  | 'bgremover'
  | 'gallery'
  | 'profile';

export interface SavedDesign {
  id: string;
  title: string;
  category: 'image' | 'template' | 'logo' | 'video' | 'custom';
  thumbnail: string;
  createdAt: string;
  aspectRatio: string;
  tags: string[];
  canvasData?: any;
}

export interface DesignTemplate {
  id: string;
  title: string;
  category: 'wedding' | 'greeting' | 'commercial' | 'business';
  categoryLabel: string;
  thumbnail: string;
  aspectRatio: '3:4' | '1:1' | '9:16' | '4:3';
  description: string;
  defaultText: {
    primary: string;
    secondary: string;
    font: string;
    color: string;
  };
}

export interface TextLayer {
  id: string;
  text: string;
  x: number;
  y: number;
  fontSize: number;
  fontFamily: 'Cairo' | 'Amiri' | 'Tajawal';
  color: string;
  isGoldGradient: boolean;
  hasShadow: boolean;
  align: 'right' | 'center' | 'left';
  fontWeight: 'normal' | 'bold';
}

export interface LogoConfig {
  style: 'monogram' | 'crest' | 'kufic' | 'seal' | 'modern';
  brandName: string;
  brandSlogan: string;
  monogramText: string;
  colorScheme: 'gold' | 'gold-black' | 'platinum' | 'navy-gold' | 'emerald-gold';
  iconType: 'crown' | 'falcon' | 'shield' | 'star' | 'diamond' | 'geometric';
}
