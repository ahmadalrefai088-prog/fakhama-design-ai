/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ActiveTab, SavedDesign, DesignTemplate } from './types';
import { INITIAL_DESIGNS } from './data/initialData';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { MobileToolsSheet } from './components/MobileToolsSheet';
import { HomeDashboard } from './components/HomeDashboard';
import { ImageGenerator } from './components/ImageGenerator';
import { TemplatesLibrary } from './components/TemplatesLibrary';
import { CanvasEditor } from './components/CanvasEditor';
import { AiCopywriter } from './components/AiCopywriter';
import { LogoGenerator } from './components/LogoGenerator';
import { VideoStudio } from './components/VideoStudio';
import { BackgroundRemover } from './components/BackgroundRemover';
import { DesignGallery } from './components/DesignGallery';
import { ProfileSettings } from './components/ProfileSettings';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Saved designs in state & localStorage
  const [savedDesigns, setSavedDesigns] = useState<SavedDesign[]>(() => {
    try {
      const stored = localStorage.getItem('fakhamat_designs_v1');
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.warn('Failed to parse saved designs from localStorage:', e);
    }
    return INITIAL_DESIGNS;
  });

  // Editor transfer state
  const [editorInitialBg, setEditorInitialBg] = useState<string | undefined>(undefined);
  const [editorInitialTitle, setEditorInitialTitle] = useState<string | undefined>(undefined);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('fakhamat_designs_v1', JSON.stringify(savedDesigns));
    } catch (e) {
      console.warn('Failed to save to localStorage:', e);
    }
  }, [savedDesigns]);

  // Handler to open any image or template into the canvas editor
  const handleOpenInEditor = (imageUrl: string, title: string) => {
    setEditorInitialBg(imageUrl);
    setEditorInitialTitle(title);
    setActiveTab('editor');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenTemplateInEditor = (template: DesignTemplate) => {
    handleOpenInEditor(template.thumbnail, template.title);
  };

  const handleOpenDesignInEditor = (design: SavedDesign) => {
    handleOpenInEditor(design.thumbnail, design.title);
  };

  // Handler to add design to gallery
  const handleSaveToGallery = (design: SavedDesign) => {
    setSavedDesigns((prev) => [design, ...prev]);
  };

  // Handler to delete design from gallery
  const handleDeleteDesign = (id: string) => {
    setSavedDesigns((prev) => prev.filter((d) => d.id !== id));
  };

  // Handler for text transfer from copywriter to editor
  const handleCopywriterSendToEditor = (text: string) => {
    setEditorInitialTitle(`تصميم: ${text.slice(0, 20)}`);
    setActiveTab('editor');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#09090b] text-[#f4f4f5] flex flex-col font-cairo selection:bg-[#d4af37]/30 selection:text-[#f5d77f]">
      {/* Luxury Sticky Top Bar */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        savedCount={savedDesigns.length}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 pt-6 pb-24 lg:pb-12">
        {activeTab === 'home' && (
          <HomeDashboard
            setActiveTab={setActiveTab}
            savedDesigns={savedDesigns}
            onOpenTemplateInEditor={handleOpenTemplateInEditor}
            onOpenDesignInEditor={handleOpenDesignInEditor}
          />
        )}

        {activeTab === 'generator' && (
          <ImageGenerator
            onOpenInEditor={handleOpenInEditor}
            onSaveToGallery={handleSaveToGallery}
          />
        )}

        {activeTab === 'templates' && (
          <TemplatesLibrary
            onOpenTemplateInEditor={handleOpenTemplateInEditor}
          />
        )}

        {activeTab === 'editor' && (
          <CanvasEditor
            initialBackground={editorInitialBg}
            initialTitle={editorInitialTitle}
            onSaveToGallery={handleSaveToGallery}
          />
        )}

        {activeTab === 'copywriter' && (
          <AiCopywriter
            onSendToEditor={handleCopywriterSendToEditor}
          />
        )}

        {activeTab === 'logo' && (
          <LogoGenerator
            onOpenInEditor={handleOpenInEditor}
            onSaveToGallery={handleSaveToGallery}
          />
        )}

        {activeTab === 'video' && (
          <VideoStudio
            onOpenInEditor={handleOpenInEditor}
          />
        )}

        {activeTab === 'bgremover' && (
          <BackgroundRemover
            onOpenInEditor={handleOpenInEditor}
          />
        )}

        {activeTab === 'gallery' && (
          <DesignGallery
            designs={savedDesigns}
            onOpenDesignInEditor={handleOpenDesignInEditor}
            onDeleteDesign={handleDeleteDesign}
            setActiveTab={setActiveTab}
          />
        )}

        {activeTab === 'profile' && (
          <ProfileSettings
            savedDesignsCount={savedDesigns.length}
          />
        )}
      </main>

      {/* Mobile Ergonomic Bottom Navigation Bar */}
      <BottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenMobileMenu={() => setIsMobileMenuOpen(true)}
      />

      {/* Mobile Tools Sheet Drawer */}
      <MobileToolsSheet
        isOpen={isMobileMenuOpen}
        onClose={() => setIsMobileMenuOpen(false)}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />
    </div>
  );
}
