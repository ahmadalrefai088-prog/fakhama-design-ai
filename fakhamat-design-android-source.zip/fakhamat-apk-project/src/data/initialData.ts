import { DesignTemplate, SavedDesign } from '../types';

export const ASSET_PATHS = {
  wedding: '/src/assets/images/luxury_wedding_invitation_1794046247251.jpg',
  perfume: '/src/assets/images/luxury_perfume_ad_1794046248250.jpg',
  eid: '/src/assets/images/luxury_eid_greeting_1794046247629.jpg',
  logoMockup: '/src/assets/images/luxury_gold_logo_mockup_1794046246653.jpg',
};

export const INITIAL_TEMPLATES: DesignTemplate[] = [
  {
    id: 'tpl-wedding-1',
    title: 'دعوة زفاف ملكية فاخرة',
    category: 'wedding',
    categoryLabel: 'دعوات زفاف',
    thumbnail: ASSET_PATHS.wedding,
    aspectRatio: '3:4',
    description: 'تصميم ملكي مخملي بأسلوب النقش الذهبي البارز مع زخارف أندلسية راقية.',
    defaultText: {
      primary: 'دعوة زفاف كريمة',
      secondary: 'نتشرف بدعوتكم لحضور حفل الزفاف البهيج',
      font: 'Amiri',
      color: '#F5D77F',
    },
  },
  {
    id: 'tpl-perfume-1',
    title: 'إعلان تجاري لعطر ملكي',
    category: 'commercial',
    categoryLabel: 'إعلانات فاخرة',
    thumbnail: ASSET_PATHS.perfume,
    aspectRatio: '4:3',
    description: 'تصوير استوديو تجاري على رخام أسود مع انعكاسات ذهبية ساحرة وضباب خفيف.',
    defaultText: {
      primary: 'أريج الفخامة الخالدة',
      secondary: 'خصم حصري 30% لأصحاب الذوق الرفيع',
      font: 'Cairo',
      color: '#FFFFFF',
    },
  },
  {
    id: 'tpl-eid-1',
    title: 'بطاقة تهنئة بالأعياد والمناسبات',
    category: 'greeting',
    categoryLabel: 'تهاني ومناسبات',
    thumbnail: ASSET_PATHS.eid,
    aspectRatio: '3:4',
    description: 'قوس إسلامي مذهب مع هلال مضيء ومشكاة ذهبية على خلفية ليلية مخملية.',
    defaultText: {
      primary: 'عيد مبارك سعيد',
      secondary: 'كل عام وأنتم بخير وسعادة دائمة',
      font: 'Amiri',
      color: '#F5D77F',
    },
  },
  {
    id: 'tpl-logo-1',
    title: 'هوية وشعار مؤسسي مذهب',
    category: 'business',
    categoryLabel: 'هوية وبطاقات',
    thumbnail: ASSET_PATHS.logoMockup,
    aspectRatio: '1:1',
    description: 'ختم مونوغرام ملكي مطبوع بتقنية الذهب الحراري البارز على كرت فاخر.',
    defaultText: {
      primary: 'فخامة النخبة',
      secondary: 'استشارات وتصاميم حصرية',
      font: 'Cairo',
      color: '#D4AF37',
    },
  },
  {
    id: 'tpl-wedding-2',
    title: 'بطاقة عقد قران وملكة',
    category: 'wedding',
    categoryLabel: 'دعوات زفاف',
    thumbnail: ASSET_PATHS.wedding,
    aspectRatio: '3:4',
    description: 'إطار ذهبي ناعم مع تفاصيل خط الثلث العربي الأصيل ولمسات لؤلؤية.',
    defaultText: {
      primary: 'بارك الله لهما وبارك عليهما',
      secondary: 'يسعدنا تشريفكم بمناسبة عقد القران المبارك',
      font: 'Amiri',
      color: '#F5D77F',
    },
  },
  {
    id: 'tpl-commercial-2',
    title: 'عرض مجوهرات وساعات النخبة',
    category: 'commercial',
    categoryLabel: 'إعلانات فاخرة',
    thumbnail: ASSET_PATHS.perfume,
    aspectRatio: '4:3',
    description: 'قالب إعلاني مخصص لمنصات التواصل سناب شات وإنستغرام بحواف ذهبية.',
    defaultText: {
      primary: 'مجموعة النخبة 2026',
      secondary: 'بريق يستحق اقتناءك',
      font: 'Tajawal',
      color: '#D4AF37',
    },
  },
];

export const INITIAL_DESIGNS: SavedDesign[] = [
  {
    id: 'des-001',
    title: 'دعوة زفاف سارة وخالد الملكية',
    category: 'template',
    thumbnail: ASSET_PATHS.wedding,
    createdAt: 'اليوم، 10:30 ص',
    aspectRatio: '3:4',
    tags: ['دعوة زفاف', 'مخمل أسود', 'ذهب خالص'],
  },
  {
    id: 'des-002',
    title: 'حملة عطر أمالفي - إعلان إنستغرام',
    category: 'image',
    thumbnail: ASSET_PATHS.perfume,
    createdAt: 'أمس، 06:15 م',
    aspectRatio: '4:3',
    tags: ['عطور فاخرة', 'إعلان تجاري', 'رخام أسود'],
  },
  {
    id: 'des-003',
    title: 'تهنئة عيد الفطر المبارك',
    category: 'template',
    thumbnail: ASSET_PATHS.eid,
    createdAt: '03 نوفمبر 2026',
    aspectRatio: '3:4',
    tags: ['تهاني', 'هلال ذهبي', 'مناسبات'],
  },
  {
    id: 'des-004',
    title: 'شعار أوروم رويال Aurum Royale',
    category: 'logo',
    thumbnail: ASSET_PATHS.logoMockup,
    createdAt: '01 نوفمبر 2026',
    aspectRatio: '1:1',
    tags: ['شعار مذهب', 'هوية بصرية', 'مونوغرام'],
  },
];

export const IMAGE_STYLES = [
  { id: 'royal_gold', label: 'فخامة ملكية مذهبة', desc: 'ذهب عيار 24 مع خلفية أونيكس سوداء وإضاءة درامية' },
  { id: 'commercial_studio', label: 'استوديو تجاري فائق الواقعية', desc: 'تصوير إعلانات المنتجات على رخام فاخر مع انعكاسات' },
  { id: 'arabic_calligraphy', label: 'مخطوطات وقباب عربية', desc: 'زخارف إسلامية مع خط ثلث وأقواس أندلسية مضيئة' },
  { id: 'cinematic_3d', label: 'سينمائي ثلاثي الأبعاد', desc: 'إخراج إضاءة هوليوودي مع تفاصيل مجسمة ومؤثرات جزيئات' },
  { id: 'luxury_minimal', label: 'بساطة فاخرة (Minimal Luxury)', desc: 'خطوط هندسية نقية وألوان هادئة بلمسات ذهب مطفأ' },
];

export const VIDEO_PRESETS = [
  {
    id: 'vid-perfume',
    title: 'قصة إعلان عطر ملكي (Motion Reel)',
    image: ASSET_PATHS.perfume,
    headline: 'أريج الفخامة الذي لا يُنسى',
    subline: 'عطر النخبة الجديد متوفر الآن بحسم 30%',
    duration: 6,
    soundTrack: 'نغمات بيانو كلاسيكية هادئة',
  },
  {
    id: 'vid-wedding',
    title: 'دعوة زفاف تفاعلية متحركة',
    image: ASSET_PATHS.wedding,
    headline: 'فرحتنا تكتمل بوجودكم معنا',
    subline: 'حفل زفاف سارة وخالد · فندق الريتز كارلتون',
    duration: 8,
    soundTrack: 'موسيقى أوتار شرقية ملكية',
  },
  {
    id: 'vid-eid',
    title: 'تهنئة العيد ببريق الذهب المتحرك',
    image: ASSET_PATHS.eid,
    headline: 'تقبل الله طاعتكم وعيدكم مبارك',
    subline: 'كل عام وأنتم ونحن بألف خير وسلام',
    duration: 5,
    soundTrack: 'تهليلات وأجواء احتفالية راقية',
  },
];
