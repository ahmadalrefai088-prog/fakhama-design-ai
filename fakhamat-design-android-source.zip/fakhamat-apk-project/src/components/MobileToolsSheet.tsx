import React from 'react';
import {
  X,
  Sparkles,
  LayoutGrid,
  Edit3,
  PenTool,
  Award,
  Video,
  Scissors,
  Bookmark,
  User,
  ShieldCheck,
  ChevronLeft
} from 'lucide-react';
import { ActiveTab } from '../types';

interface MobileToolsSheetProps {
  isOpen: boolean;
  onClose: () => void;
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
}

export const MobileToolsSheet: React.FC<MobileToolsSheetProps> = ({
  isOpen,
  onClose,
  activeTab,
  setActiveTab,
}) => {
  if (!isOpen) return null;

  const tools = [
    {
      id: 'generator' as ActiveTab,
      title: 'إنشاء الصور بالذكاء الاصطناعي',
      desc: 'توليد لوحات وتصاميم سينمائية فاخرة بالأبعاد المطلوبة',
      icon: Sparkles,
      tag: 'AI',
    },
    {
      id: 'templates' as ActiveTab,
      title: 'قوالب جاهزة فاخرة',
      desc: 'دعوات زفاف، تهاني الأعياد، إعلانات وبطاقات أعمال',
      icon: LayoutGrid,
      tag: 'قوالب',
    },
    {
      id: 'editor' as ActiveTab,
      title: 'محرر التصاميم والصور',
      desc: 'إضافة نصوص عربية بخطوط راقية وتعديل الألوان والفلاتر',
      icon: Edit3,
      tag: 'محرر',
    },
    {
      id: 'copywriter' as ActiveTab,
      title: 'المساعد الذكي وتصحيح الإملاء',
      desc: 'صياغة إعلانات مقنعة وتدقيق لغوي فوري بنكهة ملكية',
      icon: PenTool,
      tag: 'نصوص',
    },
    {
      id: 'logo' as ActiveTab,
      title: 'مصمم الشعارات الفاخرة',
      desc: 'شعارات مونوغرام وتيجان وأختام ملكية مع موك اب واقعي',
      icon: Award,
      tag: 'شعارات',
    },
    {
      id: 'video' as ActiveTab,
      title: 'أستوديو الفيديو والقصص المتحركة',
      desc: 'تصميم ستوري وريلز متحركة ببريق الذهب ومؤثرات صوتية',
      icon: Video,
      tag: 'فيديو',
    },
    {
      id: 'bgremover' as ActiveTab,
      title: 'أداة تفريغ خلفية الصور',
      desc: 'عزل المنتجات والأشخاص بدقة فائقة وتصديرها بصيغة PNG',
      icon: Scissors,
      tag: 'أداة ذكية',
    },
    {
      id: 'gallery' as ActiveTab,
      title: 'معرض تصاميمي المحفوظة',
      desc: 'استعراض كافة أعمالك السابقة وتنزيلها وإعادة تحريرها',
      icon: Bookmark,
      tag: 'المحفوظات',
    },
    {
      id: 'profile' as ActiveTab,
      title: 'الملف الشخصي وإعدادات APK',
      desc: 'إدارة العضوية، إعدادات الدقة، وطريقة تثبيت التطبيق لأندرويد',
      icon: User,
      tag: 'حسابي',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end bg-black/70 backdrop-blur-sm lg:hidden animate-fade-in">
      <div
        className="w-full bg-[#121216] border-t border-zinc-800 rounded-t-3xl max-h-[85vh] flex flex-col overflow-hidden shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Sheet Drag / Header */}
        <div className="p-4 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#d4af37]/20 border border-[#d4af37]/30 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4 text-[#f5d77f]" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">جميع أدوات فخامة التصميم</h3>
              <p className="text-[11px] text-zinc-400">اختر الأداة للبدء فوراً</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center text-zinc-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tools List */}
        <div className="p-3 overflow-y-auto space-y-1.5 pb-8">
          {tools.map((tool) => {
            const Icon = tool.icon;
            const isSelected = activeTab === tool.id;
            return (
              <button
                key={tool.id}
                onClick={() => {
                  setActiveTab(tool.id);
                  onClose();
                }}
                className={`w-full p-3 rounded-2xl flex items-center justify-between text-right transition-all ${
                  isSelected
                    ? 'bg-[#d4af37]/15 border border-[#d4af37]/40 text-white'
                    : 'bg-zinc-900/80 border border-zinc-800/80 text-zinc-200 hover:bg-zinc-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                      isSelected
                        ? 'bg-[#d4af37] text-zinc-950 font-bold'
                        : 'bg-zinc-800 text-[#f5d77f]'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm">{tool.title}</span>
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-zinc-800 text-zinc-400">
                        {tool.tag}
                      </span>
                    </div>
                    <p className="text-xs text-zinc-400 mt-0.5 line-clamp-1">{tool.desc}</p>
                  </div>
                </div>
                <ChevronLeft className="w-4 h-4 text-zinc-500 shrink-0" />
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
