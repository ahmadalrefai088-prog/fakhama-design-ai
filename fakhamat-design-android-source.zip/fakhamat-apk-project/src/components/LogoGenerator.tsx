import React, { useState, useRef } from 'react';
import {
  Award,
  Crown,
  Download,
  Bookmark,
  Edit3,
  Layers,
  Sparkles,
  Smartphone,
  CreditCard,
  Building,
  Package,
  Check
} from 'lucide-react';
import { LogoConfig, SavedDesign } from '../types';
import { ASSET_PATHS } from '../data/initialData';

interface LogoGeneratorProps {
  onOpenInEditor: (logoDataUrl: string, title: string) => void;
  onSaveToGallery: (design: SavedDesign) => void;
}

export const LogoGenerator: React.FC<LogoGeneratorProps> = ({
  onOpenInEditor,
  onSaveToGallery,
}) => {
  const [config, setConfig] = useState<LogoConfig>({
    style: 'crest',
    brandName: 'فخامة النخبة',
    brandSlogan: 'العراقة والتميز برؤية ملكية',
    monogramText: 'ف',
    colorScheme: 'gold',
    iconType: 'crown',
  });

  const [activeMockup, setActiveMockup] = useState<'card' | 'glass' | 'box' | 'mobile'>('card');
  const [savedSuccess, setSavedSuccess] = useState(false);
  const svgRef = useRef<SVGSVGElement | null>(null);

  const styles = [
    { id: 'crest', label: 'شارة ملكية مع تاج', desc: 'درع كلاسيكي مع تاج وزخارف ذهبية' },
    { id: 'monogram', label: 'مونوغرام حرفي', desc: 'حروف عربية متداخلة داخل دائرة مذهبة' },
    { id: 'kufic', label: 'كوفي هندسي فاخر', desc: 'خط كوفي مربع بنمط أرابيسك ذهبي' },
    { id: 'modern', label: 'عصري وبسيط (Minimal)', desc: 'خطوط نقية وعصرية تناسب الشركات الفاخرة' },
  ];

  const colorPalettes = [
    { id: 'gold', label: 'ذهب ملكي عيار 24', primary: '#D4AF37', secondary: '#F5D77F', bg: '#09090b' },
    { id: 'gold-black', label: 'أسود مع ذهب ناصع', primary: '#F5D77F', secondary: '#D4AF37', bg: '#121215' },
    { id: 'platinum', label: 'فضي بلاتيني', primary: '#E2E8F0', secondary: '#94A3B8', bg: '#0F172A' },
    { id: 'navy-gold', label: 'كحلي داكن وذهب', primary: '#D4AF37', secondary: '#F5D77F', bg: '#0B132B' },
    { id: 'emerald-gold', label: 'زمردي ملكي وذهب', primary: '#F5D77F', secondary: '#D4AF37', bg: '#062C22' },
  ];

  const currentPalette = colorPalettes.find((p) => p.id === config.colorScheme) || colorPalettes[0];

  // Export SVG to PNG Data URL
  const exportLogoDataUrl = (): string => {
    const svg = svgRef.current;
    if (!svg) return '';
    const svgData = new XMLSerializer().serializeToString(svg);
    const canvas = document.createElement('canvas');
    canvas.width = 800;
    canvas.height = 800;
    const ctx = canvas.getContext('2d');
    if (!ctx) return '';

    const img = new Image();
    const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
    const URL = window.URL || window.webkitURL || window;
    const blobURL = URL.createObjectURL(svgBlob);

    img.src = blobURL;
    // draw background
    ctx.fillStyle = currentPalette.bg;
    ctx.fillRect(0, 0, 800, 800);
    ctx.drawImage(img, 0, 0, 800, 800);
    return canvas.toDataURL('image/png');
  };

  const handleDownloadPNG = () => {
    const dataUrl = exportLogoDataUrl();
    const link = document.createElement('a');
    link.download = `شعار_${config.brandName.replace(/\s+/g, '_')}.png`;
    link.href = dataUrl;
    link.click();
  };

  const handleSave = () => {
    const dataUrl = exportLogoDataUrl();
    const newDesign: SavedDesign = {
      id: `logo-${Date.now()}`,
      title: `شعار: ${config.brandName}`,
      category: 'logo',
      thumbnail: dataUrl || ASSET_PATHS.logoMockup,
      createdAt: 'الآن',
      aspectRatio: '1:1',
      tags: ['شعار', config.style, config.colorScheme],
    };

    onSaveToGallery(newDesign);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="space-y-6 pb-12 animate-fade-in max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-800 pb-4">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <Award className="w-6 h-6 text-[#f5d77f]" />
            مصمم الشعارات الملكية والهوية البصرية
          </h1>
          <p className="text-xs text-zinc-400 mt-1">
            صمم شعاراً استثنائياً لمؤسستك أو مناسبتك مع استعراض مباشر على موك اب ثلاثي الأبعاد
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleDownloadPNG}
            className="px-3 py-2 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#f5d77f] text-[#09090b] font-bold text-xs flex items-center gap-1.5 shadow-sm shadow-[#d4af37]/20"
          >
            <Download className="w-4 h-4" />
            <span>تنزيل الشعار PNG</span>
          </button>

          <button
            onClick={handleSave}
            className="px-3 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-semibold text-xs flex items-center gap-1.5 transition-colors"
          >
            {savedSuccess ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                <span className="text-emerald-400">تم الحفظ</span>
              </>
            ) : (
              <>
                <Bookmark className="w-4 h-4 text-[#f5d77f]" />
                <span>حفظ بالمعرض</span>
              </>
            )}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Customization Controls */}
        <div className="lg:col-span-5 space-y-4">
          <div className="rounded-2xl bg-zinc-900/90 border border-zinc-800 p-5 space-y-4 shadow-xl">
            {/* Brand Name Input */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-zinc-200">اسم العلامة التجارية / المؤسسة:</label>
              <input
                type="text"
                value={config.brandName}
                onChange={(e) => setConfig({ ...config, brandName: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-800 focus:border-[#d4af37] rounded-xl px-3 py-2 text-sm text-white font-bold focus:outline-none"
              />
            </div>

            {/* Slogan Input */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-zinc-200">الشعار اللفظي (Slogan / الوصف):</label>
              <input
                type="text"
                value={config.brandSlogan}
                onChange={(e) => setConfig({ ...config, brandSlogan: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-800 focus:border-[#d4af37] rounded-xl px-3 py-2 text-xs text-zinc-300 focus:outline-none"
              />
            </div>

            {/* Monogram Letter Input */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-zinc-200">الحرف الرمزي للمونوغرام (حرف أو اثنين):</label>
              <input
                type="text"
                maxLength={3}
                value={config.monogramText}
                onChange={(e) => setConfig({ ...config, monogramText: e.target.value })}
                className="w-24 bg-zinc-950 border border-zinc-800 focus:border-[#d4af37] rounded-xl px-3 py-2 text-center text-base text-[#f5d77f] font-black focus:outline-none"
              />
            </div>

            {/* Logo Style Picker */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-200">نمط الشعار:</label>
              <div className="grid grid-cols-2 gap-2">
                {styles.map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => setConfig({ ...config, style: s.id as any })}
                    className={`p-3 rounded-xl border text-right transition-all flex flex-col justify-between ${
                      config.style === s.id
                        ? 'bg-[#d4af37]/20 border-[#d4af37] text-white'
                        : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-zinc-700'
                    }`}
                  >
                    <span className="text-xs font-bold">{s.label}</span>
                    <span className="text-[10px] text-zinc-400 mt-1 line-clamp-1">{s.desc}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Color Scheme Picker */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-200">لوحة الألوان الملكية:</label>
              <div className="grid grid-cols-1 gap-2">
                {colorPalettes.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setConfig({ ...config, colorScheme: p.id as any })}
                    className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-between transition-all ${
                      config.colorScheme === p.id
                        ? 'bg-[#d4af37]/15 border-[#d4af37] text-white'
                        : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-5 h-5 rounded-full border border-white/20" style={{ backgroundColor: p.primary }} />
                      <span>{p.label}</span>
                    </div>
                    {config.colorScheme === p.id && <Check className="w-4 h-4 text-[#f5d77f]" />}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Live SVG Renderer & 3D Mockup Stage */}
        <div className="lg:col-span-7 space-y-5">
          {/* Mockup Selector Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            <span className="text-xs text-zinc-400 shrink-0 ml-1">عرض الشعار على:</span>
            {[
              { id: 'card', label: 'كرت أعمال مذهب', icon: CreditCard },
              { id: 'glass', label: 'واجهة زجاجية', icon: Building },
              { id: 'box', label: 'علبة هدايا ومجوهرات', icon: Package },
              { id: 'mobile', label: 'أيقونة تطبيق جوال', icon: Smartphone },
            ].map((m) => {
              const Icon = m.icon;
              return (
                <button
                  key={m.id}
                  onClick={() => setActiveMockup(m.id as any)}
                  className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 whitespace-nowrap transition-all ${
                    activeMockup === m.id
                      ? 'bg-gradient-to-r from-[#d4af37] to-[#f5d77f] text-[#09090b] border-[#d4af37]'
                      : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{m.label}</span>
                </button>
              );
            })}
          </div>

          {/* Interactive Mockup Container */}
          <div className="relative rounded-3xl overflow-hidden border border-zinc-800 shadow-2xl p-6 sm:p-10 flex items-center justify-center min-h-[460px] bg-gradient-to-b from-[#18181d] via-[#121216] to-[#09090b]">
            {/* Visual background simulation according to selected mockup */}
            {activeMockup === 'card' && (
              <div className="w-full max-w-md aspect-[16/10] rounded-2xl bg-gradient-to-br from-[#121215] to-[#050507] border-2 border-[#d4af37]/40 shadow-2xl shadow-black p-6 flex flex-col items-center justify-center relative overflow-hidden group">
                {/* Paper texture and subtle foil sheen */}
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-amber-500/10 via-transparent to-transparent pointer-events-none" />
                <div className="w-full h-full flex flex-col items-center justify-center text-center scale-90 sm:scale-100">
                  <LogoSvgPreview config={config} palette={currentPalette} refElement={svgRef} />
                </div>
              </div>
            )}

            {activeMockup === 'glass' && (
              <div className="w-full max-w-lg aspect-video rounded-2xl bg-slate-900/40 backdrop-blur-xl border border-white/20 shadow-2xl p-8 flex flex-col items-center justify-center relative overflow-hidden">
                <div className="absolute -top-12 -left-12 w-48 h-48 bg-[#d4af37]/20 rounded-full blur-3xl pointer-events-none" />
                <div className="scale-95">
                  <LogoSvgPreview config={config} palette={currentPalette} refElement={svgRef} />
                </div>
                <div className="absolute bottom-3 text-[10px] text-zinc-400 tracking-widest uppercase">
                  HAUTE COUTURE & LUXURY DESIGN
                </div>
              </div>
            )}

            {activeMockup === 'box' && (
              <div className="w-full max-w-sm aspect-square rounded-3xl bg-[#09090b] border-4 border-[#27272a] shadow-2xl p-6 flex flex-col items-center justify-center relative">
                <div className="w-20 h-1 bg-[#d4af37]/40 rounded-full absolute top-4" />
                <div className="scale-90">
                  <LogoSvgPreview config={config} palette={currentPalette} refElement={svgRef} />
                </div>
              </div>
            )}

            {activeMockup === 'mobile' && (
              <div className="flex flex-col items-center gap-3">
                <div className="w-36 h-36 rounded-3xl bg-gradient-to-br from-[#121215] to-[#09090b] border-2 border-[#d4af37]/60 shadow-2xl flex items-center justify-center p-3 relative group overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-tr from-[#d4af37]/20 to-transparent pointer-events-none" />
                  <div className="scale-75">
                    <LogoSvgPreview config={config} palette={currentPalette} refElement={svgRef} compact />
                  </div>
                </div>
                <span className="text-xs font-bold text-white">{config.brandName}</span>
                <span className="text-[10px] text-zinc-400">تطبيق أندرويد APK</span>
              </div>
            )}
          </div>

          {/* Quick Actions Footer */}
          <div className="flex items-center justify-between p-4 rounded-2xl bg-zinc-900/80 border border-zinc-800">
            <span className="text-xs text-zinc-300">
              يمكنك فتح الشعار داخل محرر التصاميم لإضافته كعلامة مائية أو دمجه مع تصاميمك.
            </span>

            <button
              onClick={() => {
                const dataUrl = exportLogoDataUrl();
                onOpenInEditor(dataUrl, `شعار ${config.brandName}`);
              }}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#f5d77f] text-[#09090b] font-bold text-xs flex items-center gap-1.5 shadow-sm shadow-[#d4af37]/20 hover:opacity-95 shrink-0"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>فتح في المحرر</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Subcomponent for SVG rendering
interface LogoSvgProps {
  config: LogoConfig;
  palette: { primary: string; secondary: string; bg: string };
  refElement: React.RefObject<SVGSVGElement | null>;
  compact?: boolean;
}

const LogoSvgPreview: React.FC<LogoSvgProps> = ({ config, palette, refElement, compact }) => {
  return (
    <svg
      ref={refElement}
      viewBox="0 0 400 360"
      className="w-full max-w-[340px] h-auto overflow-visible select-none"
    >
      <defs>
        <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor={palette.secondary} />
          <stop offset="50%" stopColor={palette.primary} />
          <stop offset="100%" stopColor="#aa8022" />
        </linearGradient>
        <filter id="goldGlow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="3" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
      </defs>

      {/* Emblem / Icon based on style */}
      {config.style === 'crest' && (
        <g transform="translate(200, 100)" textAnchor="middle">
          {/* Crown */}
          <path
            d="M-40 -40 L-20 -15 L0 -50 L20 -15 L40 -40 L35 0 L-35 0 Z"
            fill="url(#goldGrad)"
            stroke={palette.primary}
            strokeWidth="1.5"
          />
          {/* Shield Outline */}
          <path
            d="M-55 5 C-55 45, 0 85, 0 85 C0 85, 55 45, 55 5 L-55 5 Z"
            fill="none"
            stroke="url(#goldGrad)"
            strokeWidth="3.5"
          />
          {/* Inner Monogram */}
          <text
            x="0"
            y="55"
            fontSize="36"
            fontFamily="Amiri, serif"
            fontWeight="bold"
            fill="url(#goldGrad)"
            textAnchor="middle"
          >
            {config.monogramText}
          </text>
        </g>
      )}

      {config.style === 'monogram' && (
        <g transform="translate(200, 105)" textAnchor="middle">
          {/* Outer Ornamental Ring */}
          <circle cx="0" cy="0" r="65" fill="none" stroke="url(#goldGrad)" strokeWidth="3" />
          <circle
            cx="0"
            cy="0"
            r="56"
            fill="none"
            stroke={palette.secondary}
            strokeWidth="1"
            strokeDasharray="4 3"
          />
          {/* Letter */}
          <text
            x="0"
            y="22"
            fontSize="64"
            fontFamily="Amiri, serif"
            fontWeight="bold"
            fill="url(#goldGrad)"
            textAnchor="middle"
          >
            {config.monogramText}
          </text>
        </g>
      )}

      {config.style === 'kufic' && (
        <g transform="translate(200, 105)" textAnchor="middle">
          {/* Diamond / Square geometric Arabesque */}
          <rect
            x="-45"
            y="-45"
            width="90"
            height="90"
            rx="12"
            transform="rotate(45)"
            fill="none"
            stroke="url(#goldGrad)"
            strokeWidth="3"
          />
          <text
            x="0"
            y="18"
            fontSize="48"
            fontFamily="Cairo, sans-serif"
            fontWeight="900"
            fill="url(#goldGrad)"
            textAnchor="middle"
          >
            {config.monogramText}
          </text>
        </g>
      )}

      {config.style === 'modern' && (
        <g transform="translate(200, 105)" textAnchor="middle">
          {/* Clean minimal luxury geometric marks */}
          <line x1="-60" y1="0" x2="-25" y2="0" stroke="url(#goldGrad)" strokeWidth="2" />
          <line x1="25" y1="0" x2="60" y2="0" stroke="url(#goldGrad)" strokeWidth="2" />
          <polygon points="0,-30 26,15 -26,15" fill="none" stroke="url(#goldGrad)" strokeWidth="2.5" />
          <text
            x="0"
            y="8"
            fontSize="24"
            fontFamily="Cairo, sans-serif"
            fontWeight="bold"
            fill="url(#goldGrad)"
            textAnchor="middle"
          >
            {config.monogramText}
          </text>
        </g>
      )}

      {/* Typography: Brand Name & Slogan */}
      {!compact && (
        <g transform="translate(200, 240)" textAnchor="middle">
          {/* Brand Name */}
          <text
            x="0"
            y="0"
            fontSize="30"
            fontFamily="Amiri, Cairo, sans-serif"
            fontWeight="bold"
            fill="url(#goldGrad)"
            letterSpacing="1"
          >
            {config.brandName}
          </text>

          {/* Hairline Golden Divider */}
          <line x1="-80" y1="18" x2="80" y2="18" stroke="url(#goldGrad)" strokeWidth="1" opacity="0.6" />
          <circle cx="0" cy="18" r="3" fill="url(#goldGrad)" />

          {/* Slogan */}
          <text
            x="0"
            y="42"
            fontSize="14"
            fontFamily="Cairo, sans-serif"
            fontWeight="400"
            fill="#d1d5db"
            letterSpacing="0.5"
          >
            {config.brandSlogan}
          </text>
        </g>
      )}
    </svg>
  );
};
