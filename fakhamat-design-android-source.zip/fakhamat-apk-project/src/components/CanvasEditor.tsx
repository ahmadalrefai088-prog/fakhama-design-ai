import React, { useState, useRef, useEffect } from 'react';
import {
  Edit3,
  Type,
  Plus,
  Trash2,
  Download,
  Bookmark,
  Layers,
  Palette,
  Sliders,
  Move,
  Upload,
  RotateCcw,
  Sparkles,
  Crown,
  Check,
  AlignRight,
  AlignCenter,
  AlignLeft,
  Bold
} from 'lucide-react';
import { TextLayer, SavedDesign, DesignTemplate } from '../types';
import { ASSET_PATHS } from '../data/initialData';

interface CanvasEditorProps {
  initialBackground?: string;
  initialTitle?: string;
  onSaveToGallery: (design: SavedDesign) => void;
}

export const CanvasEditor: React.FC<CanvasEditorProps> = ({
  initialBackground,
  initialTitle,
  onSaveToGallery,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [bgImageSrc, setBgImageSrc] = useState<string>(initialBackground || ASSET_PATHS.wedding);
  const [projectTitle, setProjectTitle] = useState(initialTitle || 'تصميم ملكي فاخر');
  const [activeFilter, setActiveFilter] = useState<'none' | 'gold' | 'noir' | 'cinematic' | 'vibrant'>('none');
  const [overlayStyle, setOverlayStyle] = useState<'none' | 'gold-border' | 'royal-seal' | 'arabesque'>('gold-border');

  // Text layers state
  const [layers, setLayers] = useState<TextLayer[]>([
    {
      id: 'layer-1',
      text: 'دعوة زفاف كريمة',
      x: 300,
      y: 200,
      fontSize: 38,
      fontFamily: 'Amiri',
      color: '#F5D77F',
      isGoldGradient: true,
      hasShadow: true,
      align: 'center',
      fontWeight: 'bold',
    },
    {
      id: 'layer-2',
      text: 'نتشرف بحضوركم لمشاركتنا فرحتنا الكبرى',
      x: 300,
      y: 280,
      fontSize: 20,
      fontFamily: 'Cairo',
      color: '#FFFFFF',
      isGoldGradient: false,
      hasShadow: true,
      align: 'center',
      fontWeight: 'normal',
    },
  ]);

  const [selectedLayerId, setSelectedLayerId] = useState<string>('layer-1');
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number } | null>(null);

  const selectedLayer = layers.find((l) => l.id === selectedLayerId) || layers[0];

  // Palette colors
  const colorOptions = [
    { label: 'ذهب خالص', value: '#D4AF37' },
    { label: 'ذهب مشرق', value: '#F5D77F' },
    { label: 'أبيض ناصع', value: '#FFFFFF' },
    { label: 'بلاتيني', value: '#E2E8F0' },
    { label: 'أسود أونيكس', value: '#121215' },
    { label: 'زمردي مذهب', value: '#059669' },
    { label: 'كهرمان دافئ', value: '#EA580C' },
  ];

  // Redraw canvas on changes
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Canvas base dimensions (600 x 800)
    canvas.width = 600;
    canvas.height = 800;

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = bgImageSrc;

    img.onload = () => {
      // 1. Draw background image
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

      // 2. Apply Image Filter Overlay
      if (activeFilter === 'gold') {
        ctx.fillStyle = 'rgba(212, 175, 55, 0.18)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      } else if (activeFilter === 'noir') {
        // High contrast dark vignette
        const gradient = ctx.createRadialGradient(300, 400, 150, 300, 400, 450);
        gradient.addColorStop(0, 'rgba(0,0,0,0.1)');
        gradient.addColorStop(1, 'rgba(0,0,0,0.7)');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      } else if (activeFilter === 'cinematic') {
        const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
        gradient.addColorStop(0, 'rgba(20, 20, 30, 0.3)');
        gradient.addColorStop(1, 'rgba(10, 10, 15, 0.6)');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      } else if (activeFilter === 'vibrant') {
        ctx.fillStyle = 'rgba(245, 215, 127, 0.1)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }

      // 3. Draw Luxury Overlays / Borders
      if (overlayStyle === 'gold-border') {
        ctx.strokeStyle = '#D4AF37';
        ctx.lineWidth = 4;
        ctx.strokeRect(20, 20, canvas.width - 40, canvas.height - 40);

        ctx.strokeStyle = 'rgba(245, 215, 127, 0.5)';
        ctx.lineWidth = 1.5;
        ctx.strokeRect(28, 28, canvas.width - 56, canvas.height - 56);

        // Corner ornaments
        const cornerSize = 16;
        ctx.fillStyle = '#D4AF37';
        ctx.fillRect(16, 16, cornerSize, cornerSize);
        ctx.fillRect(canvas.width - 16 - cornerSize, 16, cornerSize, cornerSize);
        ctx.fillRect(16, canvas.height - 16 - cornerSize, cornerSize, cornerSize);
        ctx.fillRect(canvas.width - 16 - cornerSize, canvas.height - 16 - cornerSize, cornerSize, cornerSize);
      } else if (overlayStyle === 'royal-seal') {
        // Stamp seal in corner
        ctx.save();
        ctx.strokeStyle = '#D4AF37';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(520, 100, 40, 0, Math.PI * 2);
        ctx.stroke();
        ctx.fillStyle = '#F5D77F';
        ctx.font = 'bold 12px Cairo, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('معتمد ملكياً', 520, 96);
        ctx.fillText('FAKHAMAT DESIGN', 520, 114);
        ctx.restore();
      }

      // 4. Render Text Layers
      layers.forEach((layer) => {
        ctx.save();
        ctx.font = `${layer.fontWeight} ${layer.fontSize}px "${layer.fontFamily}", Cairo, sans-serif`;
        ctx.textAlign = layer.align;
        ctx.direction = 'rtl';

        // Shadow
        if (layer.hasShadow) {
          ctx.shadowColor = 'rgba(0, 0, 0, 0.85)';
          ctx.shadowBlur = 10;
          ctx.shadowOffsetX = 0;
          ctx.shadowOffsetY = 4;
        }

        // Color or Gold Gradient
        if (layer.isGoldGradient) {
          const textMetrics = ctx.measureText(layer.text);
          const textWidth = textMetrics.width;
          let startX = layer.x - textWidth / 2;
          if (layer.align === 'right') startX = layer.x - textWidth;
          if (layer.align === 'left') startX = layer.x;

          const gradient = ctx.createLinearGradient(startX, layer.y - layer.fontSize, startX + textWidth, layer.y);
          gradient.addColorStop(0, '#f5d77f');
          gradient.addColorStop(0.5, '#d4af37');
          gradient.addColorStop(1, '#aa8022');
          ctx.fillStyle = gradient;
        } else {
          ctx.fillStyle = layer.color;
        }

        ctx.fillText(layer.text, layer.x, layer.y);

        // Highlight active layer with subtle outline
        if (layer.id === selectedLayerId) {
          ctx.save();
          ctx.shadowColor = 'transparent';
          ctx.strokeStyle = 'rgba(212, 175, 55, 0.7)';
          ctx.setLineDash([4, 4]);
          ctx.lineWidth = 1;
          const metrics = ctx.measureText(layer.text);
          let boxX = layer.x - metrics.width / 2 - 8;
          if (layer.align === 'right') boxX = layer.x - metrics.width - 8;
          if (layer.align === 'left') boxX = layer.x - 8;
          ctx.strokeRect(boxX, layer.y - layer.fontSize, metrics.width + 16, layer.fontSize + 8);
          ctx.restore();
        }

        ctx.restore();
      });
    };

    img.onerror = () => {
      // Fallback luxury background if image error
      ctx.fillStyle = '#121215';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.strokeStyle = '#D4AF37';
      ctx.lineWidth = 3;
      ctx.strokeRect(20, 20, canvas.width - 40, canvas.height - 40);
    };
  }, [bgImageSrc, layers, selectedLayerId, activeFilter, overlayStyle]);

  // Add text layer
  const handleAddLayer = () => {
    const newLayer: TextLayer = {
      id: `layer-${Date.now()}`,
      text: 'نص ملكي جديد',
      x: 300,
      y: 400 + layers.length * 40,
      fontSize: 24,
      fontFamily: 'Cairo',
      color: '#F5D77F',
      isGoldGradient: false,
      hasShadow: true,
      align: 'center',
      fontWeight: 'bold',
    };
    setLayers([...layers, newLayer]);
    setSelectedLayerId(newLayer.id);
  };

  // Update layer property
  const updateSelectedLayer = (updates: Partial<TextLayer>) => {
    if (!selectedLayer) return;
    setLayers(
      layers.map((l) => (l.id === selectedLayer.id ? { ...l, ...updates } : l))
    );
  };

  // Remove layer
  const handleDeleteLayer = (id: string) => {
    if (layers.length <= 1) return;
    const remaining = layers.filter((l) => l.id !== id);
    setLayers(remaining);
    setSelectedLayerId(remaining[0].id);
  };

  // Image upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setBgImageSrc(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Download high-res PNG
  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Render cleanly without selection dashed box for export
    const link = document.createElement('a');
    link.download = `${projectTitle.replace(/\s+/g, '_')}.png`;
    link.href = canvas.toDataURL('image/png', 1.0);
    link.click();
  };

  // Save to Gallery
  const handleSave = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    setIsSaving(true);
    const dataUrl = canvas.toDataURL('image/png', 0.9);

    const newDesign: SavedDesign = {
      id: `canvas-${Date.now()}`,
      title: projectTitle,
      category: 'custom',
      thumbnail: dataUrl,
      createdAt: 'الآن',
      aspectRatio: '3:4',
      tags: ['محرر التصاميم', selectedLayer.fontFamily, 'تصميم مخصص'],
      canvasData: { layers, activeFilter, overlayStyle },
    };

    onSaveToGallery(newDesign);
    setIsSaving(false);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  return (
    <div className="space-y-6 pb-12 animate-fade-in max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-800 pb-4">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <Edit3 className="w-6 h-6 text-[#f5d77f]" />
            محرر التصاميم والصور الفاخرة
          </h1>
          <p className="text-xs text-zinc-400 mt-1">
            أضف نصوصاً عربية بالخطوط الكلاسيكية، وعدّل الألوان والأختام والإطارات الملكية
          </p>
        </div>

        {/* Title Input & Save / Download */}
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={projectTitle}
            onChange={(e) => setProjectTitle(e.target.value)}
            className="bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#d4af37] w-48 font-bold"
            placeholder="عنوان المشروع..."
          />

          <button
            onClick={handleDownload}
            className="px-3 py-2 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#f5d77f] text-[#09090b] font-bold text-xs flex items-center gap-1.5 shadow-sm shadow-[#d4af37]/20 hover:opacity-95"
            title="تنزيل PNG"
          >
            <Download className="w-4 h-4" />
            <span className="hidden sm:inline">تنزيل PNG</span>
          </button>

          <button
            onClick={handleSave}
            disabled={isSaving}
            className="px-3 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-semibold text-xs flex items-center gap-1.5 transition-colors"
          >
            {saveSuccess ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                <span className="text-emerald-400 hidden sm:inline">تم الحفظ</span>
              </>
            ) : (
              <>
                <Bookmark className="w-4 h-4 text-[#f5d77f]" />
                <span className="hidden sm:inline">حفظ بالمعرض</span>
              </>
            )}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Canvas Preview Viewport */}
        <div className="lg:col-span-7 flex flex-col items-center">
          <div className="relative p-4 rounded-3xl bg-zinc-900/90 border border-zinc-800 shadow-2xl flex flex-col items-center max-w-full">
            {/* Viewport bar */}
            <div className="w-full flex items-center justify-between pb-3 mb-2 border-b border-zinc-800 text-xs text-zinc-400">
              <span className="font-bold text-zinc-200 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-[#f5d77f]" />
                لوحة الرسم التفاعلية (Canvas 600×800)
              </span>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="hover:text-[#f5d77f] flex items-center gap-1 text-[11px] font-semibold"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>تغيير الخلفية</span>
                </button>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleImageUpload}
                  accept="image/*"
                  className="hidden"
                />
              </div>
            </div>

            {/* HTML5 Canvas Element */}
            <div className="relative overflow-hidden rounded-2xl border border-zinc-800 shadow-inner max-w-full">
              <canvas
                ref={canvasRef}
                className="w-full max-w-[440px] sm:max-w-[480px] h-auto object-contain cursor-crosshair block rounded-xl shadow-2xl"
              />
            </div>

            <p className="text-[11px] text-zinc-400 mt-3 text-center">
              💡 يمكنك تعديل موضع النصوص عبر إحداثيات (س، ص) من الشريط الجانبي أو إضافة طبقات جديدة.
            </p>
          </div>
        </div>

        {/* Right Column: Layer Management & Typography Controls */}
        <div className="lg:col-span-5 space-y-4">
          {/* Active Layer Editor */}
          {selectedLayer && (
            <div className="rounded-2xl bg-zinc-900/90 border border-zinc-800 p-4 space-y-4 shadow-xl">
              <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Type className="w-4 h-4 text-[#f5d77f]" />
                  تعديل الطبقة النصية النشطة
                </span>
                <button
                  onClick={() => handleDeleteLayer(selectedLayer.id)}
                  className="text-xs text-red-400 hover:text-red-300 flex items-center gap-1"
                  title="حذف الطبقة"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>حذف</span>
                </button>
              </div>

              {/* Text Input */}
              <div className="space-y-1">
                <label className="text-[11px] text-zinc-400">محتوى النص (بالعربية):</label>
                <textarea
                  value={selectedLayer.text}
                  onChange={(e) => updateSelectedLayer({ text: e.target.value })}
                  rows={2}
                  className="w-full bg-zinc-950 border border-zinc-800 focus:border-[#d4af37] rounded-xl p-2.5 text-sm text-white focus:outline-none"
                />
              </div>

              {/* Font Family Selector */}
              <div className="space-y-1.5">
                <label className="text-[11px] text-zinc-400">نوع الخط العربي:</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'Amiri', name: 'الأميري الملكي', sample: 'خط ملكي' },
                    { id: 'Cairo', name: 'القاهرة الحديث', sample: 'خط عصري' },
                    { id: 'Tajawal', name: 'تجوّل الفاخر', sample: 'خط أنيق' },
                  ].map((f) => (
                    <button
                      key={f.id}
                      type="button"
                      onClick={() => updateSelectedLayer({ fontFamily: f.id as any })}
                      className={`p-2 rounded-xl border text-center transition-all ${
                        selectedLayer.fontFamily === f.id
                          ? 'bg-[#d4af37]/20 border-[#d4af37] text-[#f5d77f] font-bold'
                          : 'bg-zinc-950 border-zinc-800 text-zinc-300 hover:border-zinc-700'
                      }`}
                    >
                      <div className="text-xs">{f.name}</div>
                      <div className="text-[10px] text-zinc-400 mt-0.5">{f.sample}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Font Size & Weight */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs text-zinc-300">
                  <span>حجم الخط: {selectedLayer.fontSize}px</span>
                  <button
                    onClick={() =>
                      updateSelectedLayer({
                        fontWeight: selectedLayer.fontWeight === 'bold' ? 'normal' : 'bold',
                      })
                    }
                    className={`px-2 py-0.5 rounded text-xs flex items-center gap-1 ${
                      selectedLayer.fontWeight === 'bold'
                        ? 'bg-[#d4af37] text-zinc-950 font-bold'
                        : 'bg-zinc-800 text-zinc-300'
                    }`}
                  >
                    <Bold className="w-3 h-3" /> عريض
                  </button>
                </div>
                <input
                  type="range"
                  min={14}
                  max={80}
                  value={selectedLayer.fontSize}
                  onChange={(e) => updateSelectedLayer({ fontSize: Number(e.target.value) })}
                  className="w-full accent-[#d4af37]"
                />
              </div>

              {/* Color Palette */}
              <div className="space-y-1.5">
                <label className="text-[11px] text-zinc-400">لون النص:</label>
                <div className="flex flex-wrap gap-2">
                  {colorOptions.map((c) => (
                    <button
                      key={c.value}
                      type="button"
                      onClick={() => updateSelectedLayer({ color: c.value, isGoldGradient: false })}
                      className={`w-7 h-7 rounded-full border-2 transition-transform ${
                        selectedLayer.color === c.value && !selectedLayer.isGoldGradient
                          ? 'border-white scale-110 shadow-md'
                          : 'border-transparent hover:scale-105'
                      }`}
                      style={{ backgroundColor: c.value }}
                      title={c.label}
                    />
                  ))}
                </div>
              </div>

              {/* Gold Gradient & Shadow toggles */}
              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-zinc-800/80">
                <button
                  type="button"
                  onClick={() => updateSelectedLayer({ isGoldGradient: !selectedLayer.isGoldGradient })}
                  className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                    selectedLayer.isGoldGradient
                      ? 'bg-[#d4af37]/20 border-[#d4af37] text-[#f5d77f]'
                      : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-white'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5 text-[#f5d77f]" />
                  <span>تدرج ذهبي ملكي</span>
                </button>

                <button
                  type="button"
                  onClick={() => updateSelectedLayer({ hasShadow: !selectedLayer.hasShadow })}
                  className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                    selectedLayer.hasShadow
                      ? 'bg-[#d4af37]/20 border-[#d4af37] text-[#f5d77f]'
                      : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-white'
                  }`}
                >
                  <span>ظل وبريق ثلاثي الأبعاد</span>
                </button>
              </div>

              {/* Alignment & X/Y Position */}
              <div className="space-y-2 pt-2 border-t border-zinc-800/80">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-zinc-400 text-[11px]">محاذاة النص:</span>
                  <div className="flex gap-1 bg-zinc-950 p-1 rounded-lg border border-zinc-800">
                    <button
                      onClick={() => updateSelectedLayer({ align: 'right' })}
                      className={`p-1.5 rounded ${
                        selectedLayer.align === 'right' ? 'bg-[#d4af37] text-zinc-950' : 'text-zinc-400'
                      }`}
                    >
                      <AlignRight className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => updateSelectedLayer({ align: 'center' })}
                      className={`p-1.5 rounded ${
                        selectedLayer.align === 'center' ? 'bg-[#d4af37] text-zinc-950' : 'text-zinc-400'
                      }`}
                    >
                      <AlignCenter className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => updateSelectedLayer({ align: 'left' })}
                      className={`p-1.5 rounded ${
                        selectedLayer.align === 'left' ? 'bg-[#d4af37] text-zinc-950' : 'text-zinc-400'
                      }`}
                    >
                      <AlignLeft className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <span className="text-[10px] text-zinc-400">موضع أفقي (س): {selectedLayer.x}</span>
                    <input
                      type="range"
                      min={50}
                      max={550}
                      value={selectedLayer.x}
                      onChange={(e) => updateSelectedLayer({ x: Number(e.target.value) })}
                      className="w-full accent-[#d4af37]"
                    />
                  </div>
                  <div>
                    <span className="text-[10px] text-zinc-400">موضع رأسي (ص): {selectedLayer.y}</span>
                    <input
                      type="range"
                      min={50}
                      max={750}
                      value={selectedLayer.y}
                      onChange={(e) => updateSelectedLayer({ y: Number(e.target.value) })}
                      className="w-full accent-[#d4af37]"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Layer List Manager */}
          <div className="rounded-2xl bg-zinc-900/90 border border-zinc-800 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-[#f5d77f]" />
                قائمة الطبقات ({layers.length})
              </span>
              <button
                onClick={handleAddLayer}
                className="px-2.5 py-1 rounded-lg bg-[#d4af37]/20 border border-[#d4af37]/40 text-[#f5d77f] font-bold text-xs flex items-center gap-1 hover:bg-[#d4af37]/30"
              >
                <Plus className="w-3 h-3" />
                <span>إضافة نص</span>
              </button>
            </div>

            <div className="space-y-1.5 max-h-36 overflow-y-auto">
              {layers.map((l, index) => (
                <div
                  key={l.id}
                  onClick={() => setSelectedLayerId(l.id)}
                  className={`p-2.5 rounded-xl border text-xs flex items-center justify-between cursor-pointer transition-colors ${
                    selectedLayerId === l.id
                      ? 'bg-[#d4af37]/15 border-[#d4af37] text-white'
                      : 'bg-zinc-950 border-zinc-800/80 text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <span className="text-[10px] text-zinc-500 font-mono">0{index + 1}</span>
                    <span className="truncate max-w-[180px]">{l.text}</span>
                  </div>
                  <span className="text-[10px] text-[#f5d77f] font-semibold">{l.fontFamily}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Luxury Frames & Image Filters */}
          <div className="rounded-2xl bg-zinc-900/90 border border-zinc-800 p-4 space-y-3">
            <span className="text-xs font-bold text-white flex items-center gap-1.5">
              <Crown className="w-4 h-4 text-[#f5d77f]" />
              الإطارات والفلاتر الملكية
            </span>

            <div className="space-y-2">
              <label className="text-[11px] text-zinc-400">الإطار الزخرفي:</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'none', label: 'بدون إطار' },
                  { id: 'gold-border', label: 'إطار ذهب خالص' },
                  { id: 'royal-seal', label: 'ختم معتمد' },
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setOverlayStyle(item.id as any)}
                    className={`p-2 rounded-xl border text-xs font-semibold transition-all ${
                      overlayStyle === item.id
                        ? 'bg-[#d4af37]/20 border-[#d4af37] text-[#f5d77f]'
                        : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-white'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2 pt-2 border-t border-zinc-800/80">
              <label className="text-[11px] text-zinc-400">الفلتر الفني للصورة:</label>
              <div className="grid grid-cols-4 gap-1.5">
                {[
                  { id: 'none', label: 'طبيعي' },
                  { id: 'gold', label: 'فخامة ذهبية' },
                  { id: 'noir', label: 'أسود ملكي' },
                  { id: 'cinematic', label: 'سينمائي' },
                ].map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => setActiveFilter(f.id as any)}
                    className={`p-1.5 rounded-lg border text-[11px] font-semibold truncate transition-all ${
                      activeFilter === f.id
                        ? 'bg-[#d4af37] text-zinc-950 font-bold border-[#d4af37]'
                        : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-white'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
