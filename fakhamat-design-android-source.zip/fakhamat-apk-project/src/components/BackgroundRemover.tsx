import React, { useState, useRef, useEffect } from 'react';
import {
  Scissors,
  Upload,
  Download,
  Edit3,
  Eye,
  Sliders,
  Check,
  Sparkles,
  Layers,
  RefreshCw
} from 'lucide-react';
import { ASSET_PATHS } from '../data/initialData';

interface BackgroundRemoverProps {
  onOpenInEditor: (cutoutUrl: string, title: string) => void;
}

export const BackgroundRemover: React.FC<BackgroundRemoverProps> = ({ onOpenInEditor }) => {
  const [sourceImage, setSourceImage] = useState<string>(ASSET_PATHS.perfume);
  const [tolerance, setTolerance] = useState<number>(45);
  const [feather, setFeather] = useState<number>(2);
  const [previewBg, setPreviewBg] = useState<'transparent' | 'marble' | 'gold'>('transparent');
  const [isProcessing, setIsProcessing] = useState(false);
  const [cutoutDataUrl, setCutoutDataUrl] = useState<string>('');

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Process background cutout using Canvas pixel manipulation
  const processCutout = () => {
    setIsProcessing(true);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = sourceImage;

    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;

      // Draw original
      ctx.drawImage(img, 0, 0);

      const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = imgData.data;

      // Sample corner pixel as background color reference
      const bgR = data[0];
      const bgG = data[1];
      const bgB = data[2];

      const threshold = tolerance * 2.5;

      for (let i = 0; i < data.length; i += 4) {
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];

        // Euclidean distance from background sample or dark threshold
        const dist = Math.sqrt(
          (r - bgR) ** 2 + (g - bgG) ** 2 + (b - bgB) ** 2
        );

        if (dist < threshold || (r < 15 && g < 15 && b < 15 && tolerance > 30)) {
          // Soft feathering alpha
          if (dist > threshold - feather * 10) {
            data[i + 3] = Math.round(((dist - (threshold - feather * 10)) / (feather * 10)) * 255);
          } else {
            data[i + 3] = 0; // Transparent
          }
        }
      }

      ctx.putImageData(imgData, 0, 0);
      setCutoutDataUrl(canvas.toDataURL('image/png'));
      setIsProcessing(false);
    };

    img.onerror = () => {
      setIsProcessing(false);
    };
  };

  useEffect(() => {
    processCutout();
  }, [sourceImage, tolerance, feather]);

  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setSourceImage(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDownload = () => {
    if (!cutoutDataUrl) return;
    const link = document.createElement('a');
    link.download = 'صورة_مفرغة_فخامة_AI.png';
    link.href = cutoutDataUrl;
    link.click();
  };

  return (
    <div className="space-y-6 pb-12 animate-fade-in max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-800 pb-4">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <Scissors className="w-6 h-6 text-[#f5d77f]" />
            أداة تفريغ وإزالة خلفية الصور الذكية
          </h1>
          <p className="text-xs text-zinc-400 mt-1">
            اعزل المنتجات والمجوهرات والعطور بدقة متناهية واحصل على صورة شفافة بصيغة PNG
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => fileInputRef.current?.click()}
            className="px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-semibold text-xs flex items-center gap-1.5 transition-colors"
          >
            <Upload className="w-4 h-4 text-[#f5d77f]" />
            <span>رفع صورة من جهازك</span>
          </button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleUpload}
            accept="image/*"
            className="hidden"
          />

          <button
            onClick={handleDownload}
            disabled={!cutoutDataUrl}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#f5d77f] text-[#09090b] font-bold text-xs flex items-center gap-1.5 shadow-sm shadow-[#d4af37]/20 hover:opacity-95 disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            <span>تنزيل PNG شفاف</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Sample Switcher & Settings */}
        <div className="lg:col-span-5 space-y-4">
          <div className="rounded-2xl bg-zinc-900/90 border border-zinc-800 p-5 space-y-5 shadow-xl">
            {/* Sample selection */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-200">اختر صورة للتجربة أو ارفع صورتك:</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'perfume', label: 'عطر أمالفي', img: ASSET_PATHS.perfume },
                  { id: 'wedding', label: 'دعوة زفاف', img: ASSET_PATHS.wedding },
                  { id: 'eid', label: 'هلال ذهبي', img: ASSET_PATHS.eid },
                ].map((s) => (
                  <button
                    key={s.id}
                    onClick={() => setSourceImage(s.img)}
                    className={`rounded-xl overflow-hidden border p-1 text-center transition-all ${
                      sourceImage === s.img
                        ? 'border-[#d4af37] ring-2 ring-[#d4af37]/30 bg-[#d4af37]/10'
                        : 'border-zinc-800 hover:border-zinc-700 bg-zinc-950'
                    }`}
                  >
                    <img
                      src={s.img}
                      alt={s.label}
                      referrerPolicy="no-referrer"
                      className="w-full h-16 object-cover rounded-lg"
                    />
                    <span className="text-[10px] text-zinc-300 font-semibold block mt-1">
                      {s.label}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Sliders for Cutout Tuning */}
            <div className="space-y-3 pt-3 border-t border-zinc-800/80">
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs text-zinc-300">
                  <span>حساسية عزل الخلفية (Tolerance):</span>
                  <span className="font-bold text-[#f5d77f] font-mono">{tolerance}%</span>
                </div>
                <input
                  type="range"
                  min={10}
                  max={85}
                  value={tolerance}
                  onChange={(e) => setTolerance(Number(e.target.value))}
                  className="w-full accent-[#d4af37]"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between text-xs text-zinc-300">
                  <span>تنعيم الحواف (Feathering):</span>
                  <span className="font-bold text-[#f5d77f] font-mono">{feather}px</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={10}
                  value={feather}
                  onChange={(e) => setFeather(Number(e.target.value))}
                  className="w-full accent-[#d4af37]"
                />
              </div>
            </div>

            {/* Background preview selector */}
            <div className="space-y-2 pt-3 border-t border-zinc-800/80">
              <label className="text-xs font-bold text-zinc-200">معاينة النتيجة فوق خلفية:</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'transparent', label: 'شبكة شفافة' },
                  { id: 'marble', label: 'رخام أسود' },
                  { id: 'gold', label: 'مخمل ذهبي' },
                ].map((bg) => (
                  <button
                    key={bg.id}
                    onClick={() => setPreviewBg(bg.id as any)}
                    className={`p-2 rounded-xl border text-xs font-semibold text-center transition-all ${
                      previewBg === bg.id
                        ? 'bg-[#d4af37]/20 border-[#d4af37] text-[#f5d77f]'
                        : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-white'
                    }`}
                  >
                    {bg.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Send to Canvas Editor */}
            <div className="pt-2">
              <button
                onClick={() => {
                  if (cutoutDataUrl) {
                    onOpenInEditor(cutoutDataUrl, 'عنصر مفرغ مخصص');
                  }
                }}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#f5d77f] text-[#09090b] font-bold text-xs flex items-center justify-center gap-2 shadow-sm shadow-[#d4af37]/20 hover:opacity-95"
              >
                <Edit3 className="w-4 h-4" />
                <span>إرسال العنصر المفرغ إلى المحرر كطبقة</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Live Cutout Preview Stage */}
        <div className="lg:col-span-7 space-y-4">
          <div className="rounded-3xl bg-zinc-900/90 border border-zinc-800 p-4 shadow-2xl space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-zinc-800 text-xs text-zinc-400">
              <span className="font-bold text-white flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-[#f5d77f]" />
                المعاينة بعد التفريغ
              </span>
              <span className="text-[11px] font-mono">PNG 32-bit Transparent</span>
            </div>

            {/* The Cutout Stage Container */}
            <div
              className={`w-full min-h-[420px] rounded-2xl overflow-hidden flex items-center justify-center p-6 relative border border-zinc-800 transition-colors ${
                previewBg === 'transparent'
                  ? 'bg-[radial-gradient(#27272a_1px,transparent_1px)] [background-size:16px_16px] bg-zinc-950'
                  : previewBg === 'marble'
                  ? 'bg-gradient-to-br from-[#121215] via-[#09090b] to-[#18181d]'
                  : 'bg-gradient-to-br from-amber-950/40 via-zinc-900 to-[#121215]'
              }`}
            >
              {isProcessing && (
                <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-10">
                  <div className="flex items-center gap-2 text-[#f5d77f] text-xs font-bold">
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>جاري تفريغ الحواف...</span>
                  </div>
                </div>
              )}

              {cutoutDataUrl ? (
                <img
                  src={cutoutDataUrl}
                  alt="Cutout Preview"
                  className="max-h-[380px] max-w-full object-contain drop-shadow-2xl"
                />
              ) : (
                <div className="text-center text-zinc-500 text-xs">جاري تجهيز المعاينة...</div>
              )}
            </div>

            <canvas ref={canvasRef} className="hidden" />
          </div>
        </div>
      </div>
    </div>
  );
};
