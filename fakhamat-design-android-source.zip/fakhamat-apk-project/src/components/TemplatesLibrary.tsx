import React, { useState } from 'react';
import {
  LayoutGrid,
  Search,
  Edit3,
  Download,
  Eye,
  Crown,
  Heart,
  Share2,
  X
} from 'lucide-react';
import { DesignTemplate } from '../types';
import { INITIAL_TEMPLATES } from '../data/initialData';

interface TemplatesLibraryProps {
  onOpenTemplateInEditor: (template: DesignTemplate) => void;
}

export const TemplatesLibrary: React.FC<TemplatesLibraryProps> = ({
  onOpenTemplateInEditor,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [previewTemplate, setPreviewTemplate] = useState<DesignTemplate | null>(null);

  const categories = [
    { id: 'all', label: 'كافة القوالب الملكية' },
    { id: 'wedding', label: 'دعوات زفاف وملكة' },
    { id: 'greeting', label: 'تهاني ومناسبات' },
    { id: 'commercial', label: 'إعلانات وعروض تجارية' },
    { id: 'business', label: 'هوية وبطاقات أعمال' },
  ];

  const filtered = INITIAL_TEMPLATES.filter((tpl) => {
    const matchesCat = selectedCategory === 'all' || tpl.category === selectedCategory;
    const matchesSearch =
      tpl.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tpl.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tpl.categoryLabel.includes(searchQuery);
    return matchesCat && matchesSearch;
  });

  return (
    <div className="space-y-6 pb-12 animate-fade-in max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-800 pb-4">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <LayoutGrid className="w-6 h-6 text-[#f5d77f]" />
            مكتبة القوالب الجاهزة الفاخرة
          </h1>
          <p className="text-xs text-zinc-400 mt-1">
            تصاميم احترافية جاهزة للطباعة والنشر الإلكتروني بضغطة زر واحدة
          </p>
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث عن قالب (زفاف، عطر، عيد...)"
            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl pr-9 pl-3 py-2 text-xs text-zinc-200 placeholder:text-zinc-500 focus:outline-none focus:border-[#d4af37]"
          />
        </div>
      </div>

      {/* Category Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap shrink-0 ${
              selectedCategory === cat.id
                ? 'bg-gradient-to-r from-[#d4af37] to-[#f5d77f] text-[#09090b] shadow-md shadow-[#d4af37]/20'
                : 'bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-700'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Templates Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((tpl) => (
          <div
            key={tpl.id}
            className="group rounded-2xl bg-[#121216] border border-zinc-800 hover:border-[#d4af37]/50 overflow-hidden shadow-xl flex flex-col justify-between transition-all hover:-translate-y-1"
          >
            {/* Thumbnail */}
            <div className="relative aspect-[4/3] bg-zinc-950 overflow-hidden">
              <img
                src={tpl.thumbnail}
                alt={tpl.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute top-3 right-3 px-2.5 py-0.5 rounded-full bg-black/75 backdrop-blur-md border border-white/10 text-[10px] font-bold text-[#f5d77f]">
                {tpl.categoryLabel}
              </div>
              <div className="absolute top-3 left-3 px-2 py-0.5 rounded-md bg-black/60 backdrop-blur-md text-[10px] font-mono text-zinc-300">
                {tpl.aspectRatio}
              </div>

              {/* Hover overlay preview button */}
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                <button
                  onClick={() => setPreviewTemplate(tpl)}
                  className="p-2.5 rounded-full bg-white/20 backdrop-blur-md hover:bg-white/30 text-white transition-colors"
                  title="معاينة كاملة"
                >
                  <Eye className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Meta & Actions */}
            <div className="p-4 space-y-3">
              <div>
                <h3 className="font-bold text-sm text-white group-hover:text-[#f5d77f] transition-colors">
                  {tpl.title}
                </h3>
                <p className="text-xs text-zinc-400 mt-1 line-clamp-2 leading-relaxed">
                  {tpl.description}
                </p>
              </div>

              <div className="pt-2 border-t border-zinc-800/80 flex items-center gap-2">
                <button
                  onClick={() => onOpenTemplateInEditor(tpl)}
                  className="flex-1 py-2 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#f5d77f] text-[#09090b] font-bold text-xs flex items-center justify-center gap-1.5 hover:opacity-95 shadow-sm shadow-[#d4af37]/20 transition-opacity"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>تعديل هذا القالب</span>
                </button>

                <button
                  onClick={() => setPreviewTemplate(tpl)}
                  className="p-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white transition-colors"
                  title="معاينة"
                >
                  <Eye className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Preview Modal */}
      {previewTemplate && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in"
          onClick={() => setPreviewTemplate(null)}
        >
          <div
            className="w-full max-w-2xl bg-[#121216] border border-zinc-800 rounded-3xl p-6 shadow-2xl space-y-5"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <div className="flex items-center gap-2">
                <Crown className="w-5 h-5 text-[#f5d77f]" />
                <h3 className="font-bold text-base text-white">{previewTemplate.title}</h3>
              </div>
              <button
                onClick={() => setPreviewTemplate(null)}
                className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center text-zinc-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="relative max-h-[60vh] bg-zinc-950 rounded-2xl overflow-hidden flex items-center justify-center">
              <img
                src={previewTemplate.thumbnail}
                alt={previewTemplate.title}
                referrerPolicy="no-referrer"
                className="w-full max-h-[50vh] object-contain rounded-xl"
              />
            </div>

            <div className="space-y-2">
              <p className="text-xs text-zinc-300 leading-relaxed">
                {previewTemplate.description}
              </p>
              <div className="flex items-center gap-3 text-xs text-zinc-400">
                <span>التصنيف: {previewTemplate.categoryLabel}</span>
                <span>·</span>
                <span>الأبعاد: {previewTemplate.aspectRatio}</span>
                <span>·</span>
                <span>الخط الافتراضي: {previewTemplate.defaultText.font}</span>
              </div>
            </div>

            <div className="flex items-center gap-3 pt-2 border-t border-zinc-800">
              <button
                onClick={() => {
                  onOpenTemplateInEditor(previewTemplate);
                  setPreviewTemplate(null);
                }}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#f5d77f] text-[#09090b] font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-[#d4af37]/25"
              >
                <Edit3 className="w-4 h-4" />
                <span>فتح القالب في المحرر وتعديل النصوص</span>
              </button>

              <a
                href={previewTemplate.thumbnail}
                download={`${previewTemplate.title}.jpg`}
                className="px-4 py-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-semibold text-xs flex items-center gap-1.5 transition-colors"
              >
                <Download className="w-4 h-4 text-[#f5d77f]" />
                <span>تنزيل</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
