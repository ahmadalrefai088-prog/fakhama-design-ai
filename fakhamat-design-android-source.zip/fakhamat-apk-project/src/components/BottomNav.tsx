import React from 'react';
import { Home, Sparkles, Edit3, LayoutGrid, Layers } from 'lucide-react';
import { ActiveTab } from '../types';

interface BottomNavProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenMobileMenu: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, setActiveTab, onOpenMobileMenu }) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 lg:hidden bg-[#09090b]/95 backdrop-blur-md border-t border-zinc-800 px-2 pb-[env(safe-area-inset-bottom,4px)] pt-1">
      <div className="grid grid-cols-5 items-center h-14">
        {/* Tab 1: Home */}
        <button
          onClick={() => setActiveTab('home')}
          className={`flex flex-col items-center justify-center min-h-[44px] min-w-[44px] transition-colors ${
            activeTab === 'home' ? 'text-[#f5d77f]' : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Home className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] font-semibold tracking-tight">الرئيسية</span>
        </button>

        {/* Tab 2: Generator */}
        <button
          onClick={() => setActiveTab('generator')}
          className={`flex flex-col items-center justify-center min-h-[44px] min-w-[44px] transition-colors ${
            activeTab === 'generator' ? 'text-[#f5d77f]' : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Sparkles className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] font-semibold tracking-tight">توليد الصور</span>
        </button>

        {/* Tab 3: Editor (Centered Accent) */}
        <button
          onClick={() => setActiveTab('editor')}
          className="flex flex-col items-center justify-center min-h-[44px] min-w-[44px] -mt-3 group"
        >
          <div
            className={`w-11 h-11 rounded-full flex items-center justify-center shadow-lg transition-transform active:scale-95 ${
              activeTab === 'editor'
                ? 'bg-gradient-to-tr from-[#d4af37] to-[#f5d77f] text-[#09090b] shadow-[#d4af37]/30 ring-2 ring-[#f5d77f]/40'
                : 'bg-zinc-800 border border-zinc-700 text-zinc-300'
            }`}
          >
            <Edit3 className="w-5 h-5" />
          </div>
          <span
            className={`text-[10px] font-bold tracking-tight mt-0.5 ${
              activeTab === 'editor' ? 'text-[#f5d77f]' : 'text-zinc-400'
            }`}
          >
            المحرر
          </span>
        </button>

        {/* Tab 4: Templates */}
        <button
          onClick={() => setActiveTab('templates')}
          className={`flex flex-col items-center justify-center min-h-[44px] min-w-[44px] transition-colors ${
            activeTab === 'templates' ? 'text-[#f5d77f]' : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <LayoutGrid className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] font-semibold tracking-tight">القوالب</span>
        </button>

        {/* Tab 5: More Tools Drawer */}
        <button
          onClick={onOpenMobileMenu}
          className={`flex flex-col items-center justify-center min-h-[44px] min-w-[44px] transition-colors ${
            ['copywriter', 'logo', 'video', 'bgremover', 'gallery', 'profile'].includes(activeTab)
              ? 'text-[#f5d77f]'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Layers className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] font-semibold tracking-tight">الأدوات</span>
        </button>
      </div>
    </nav>
  );
};
