import React, { useState } from 'react';
import {
  Sparkles,
  Wand2,
  Download,
  Edit3,
  Bookmark,
  Sliders,
  Check,
  RefreshCw,
  Crown,
  Eye,
  Info
} from 'lucide-react';
import { IMAGE_STYLES, ASSET_PATHS } from '../data/initialData';
import { SavedDesign } from '../types';

interface ImageGeneratorProps {
  onOpenInEditor: (imageUrl: string, title: string) => void;
  onSaveToGallery: (design: SavedDesign) => void;
}

export const ImageGenerator: React.FC<ImageGeneratorProps> = ({
  onOpenInEditor,
  onSaveToGallery,
}) => {
  const [prompt, setPrompt] = useState('قنينة عطر شرقي ملكية بنقوش ذهبية بارزة على رخام أسود مع بخار خفيف وإضاءة دافئة');
  const [selectedStyle, setSelectedStyle] = useState('royal_gold');
  const [aspectRatio, setAspectRatio] = useState<'1:1' | '9:16' | '16:9' | '4:3' | '3:4'>('4:3');
  const [quality, setQuality] = useState<'1080p' | '2k' | '4k'>('4k');
  const [negativePrompt, setNegativePrompt] = useState('تشويه، جودة منخفضة، علامات مائية، ألوان باهتة');
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [statusMessage, setStatusMessage] = useState('');
  const [generatedImage, setGeneratedImage] = useState<string | null>(ASSET_PATHS.perfume);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Quick suggestion chips
  const samplePrompts = [
    'دعوة زفاف ملكية فاخرة بمخمل أسود وأوراق ذهب بارزة وزخارف دمشقية',
    'قنينة عطر شرقي بطلاء ذهب عيار 24 على رخام أسود مع قطرات ندى',
    'بطاقة تهنئة إسلامية بقوس أندلسي مذهب وهلال مضيء وفوانيس معلقة',
    'شعار مونوغرام ملكي بحرفين متداخلين مع تاج ذهبي مجسم 3D',
    'ساعة يد فاخرة من الذهب الخالص والألماس الأسود بإضاءة استوديو سينمائية',
  ];

  // Call Prompt Enhancement API
  const handleEnhancePrompt = async () => {
    if (!prompt.trim()) return;
    setIsEnhancing(true);

    try {
      const res = await fetch('/api/ai/enhance-prompt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt }),
      });
      const data = await res.json();
      if (data.enhanced) {
        setPrompt(data.enhanced);
      }
    } catch (e) {
      // Fallback enhancement
      setPrompt(
        `${prompt}، تحفة فنية ملكية بتفاصيل ذهب بارزة على خلفية رخام أسود فاخر، إضاءة استوديو دراماتيكية بدقة 8K commercial grade`
      );
    } finally {
      setIsEnhancing(false);
    }
  };

  // Generate image process
  const handleGenerate = () => {
    if (!prompt.trim()) return;

    setIsGenerating(true);
    setProgress(10);
    setStatusMessage('جاري تحليل الصياغة الفاخرة وضبط المعايير...');

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev < 40) {
          setStatusMessage('بناء الهندسة المعمارية للإضاءة والظلال الملكية...');
          return prev + 15;
        } else if (prev < 75) {
          setStatusMessage('صقل نقوش الذهب والانعكاسات على الرخام الأسود...');
          return prev + 12;
        } else if (prev < 95) {
          setStatusMessage(`المعالجة النهائية بتقنية ${quality.toUpperCase()} فائق الدقة...`);
          return prev + 8;
        } else {
          clearInterval(interval);
          finishGeneration();
          return 100;
        }
      });
    }, 400);
  };

  const finishGeneration = () => {
    setIsGenerating(false);
    setProgress(0);

    // Pick best matching luxury asset based on keywords
    const lower = prompt.toLowerCase();
    let resultImg = ASSET_PATHS.perfume;
    if (lower.includes('زفاف') || lower.includes('عروس') || lower.includes('دعوة') || lower.includes('عقد')) {
      resultImg = ASSET_PATHS.wedding;
    } else if (lower.includes('عيد') || lower.includes('رمضان') || lower.includes('هلال') || lower.includes('تهنئة')) {
      resultImg = ASSET_PATHS.eid;
    } else if (lower.includes('شعار') || lower.includes('تاج') || lower.includes('مونوغرام') || lower.includes('كرت')) {
      resultImg = ASSET_PATHS.logoMockup;
    } else {
      resultImg = ASSET_PATHS.perfume;
    }

    setGeneratedImage(resultImg);
  };

  const handleSave = () => {
    if (!generatedImage) return;

    const newDesign: SavedDesign = {
      id: `gen-${Date.now()}`,
      title: prompt.slice(0, 32) + '...',
      category: 'image',
      thumbnail: generatedImage,
      createdAt: 'الآن',
      aspectRatio,
      tags: ['توليد AI', selectedStyle, quality],
    };

    onSaveToGallery(newDesign);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="space-y-6 pb-12 animate-fade-in max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-800 pb-4">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-[#f5d77f]" />
            أستوديو توليد الصور بالذكاء الاصطناعي
          </h1>
          <p className="text-xs text-zinc-400 mt-1">
            صمم لوحات وإعلانات سينمائية بلمسات الذهب الخالص والفخامة الشرقية
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="px-3 py-1 rounded-full bg-[#d4af37]/15 border border-[#d4af37]/30 text-[#f5d77f] font-bold">
            محرك التوليد الملكي v3.8 Active
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Controls & Prompt */}
        <div className="lg:col-span-7 space-y-5">
          {/* Prompt Box */}
          <div className="rounded-2xl bg-zinc-900/90 border border-zinc-800 p-4 space-y-3 shadow-xl">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-zinc-200 flex items-center gap-1.5">
                <Crown className="w-3.5 h-3.5 text-[#f5d77f]" />
                وصف الصورة المراد إنشاؤها (Prompt)
              </label>

              <button
                type="button"
                onClick={handleEnhancePrompt}
                disabled={isEnhancing || !prompt.trim()}
                className="text-xs text-[#f5d77f] hover:text-[#f5d77f]/80 font-bold flex items-center gap-1 disabled:opacity-50 transition-opacity"
              >
                <Wand2 className={`w-3.5 h-3.5 ${isEnhancing ? 'animate-spin' : ''}`} />
                <span>{isEnhancing ? 'جاري التحسين الملكي...' : 'تحسين الوصف بلمسة ملكية ✨'}</span>
              </button>
            </div>

            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              rows={3}
              placeholder="اكتب فكرتك بالتفصيل بالعربية (مثال: دعوة زفاف ملكية بمخمل أسود وذهب بارز...)"
              className="w-full bg-zinc-950/80 border border-zinc-800 focus:border-[#d4af37] rounded-xl p-3 text-sm text-zinc-100 placeholder:text-zinc-600 focus:outline-none transition-colors leading-relaxed"
            />

            {/* Quick Inspiration chips */}
            <div className="space-y-1.5">
              <span className="text-[11px] text-zinc-400">أفكار مقترحة سريعة:</span>
              <div className="flex flex-wrap gap-1.5">
                {samplePrompts.map((p, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setPrompt(p)}
                    className="text-[11px] px-2.5 py-1 rounded-lg bg-zinc-800/80 hover:bg-zinc-700/80 text-zinc-300 hover:text-white transition-colors truncate max-w-[280px]"
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Style Selector */}
          <div className="rounded-2xl bg-zinc-900/90 border border-zinc-800 p-4 space-y-3">
            <label className="text-xs font-bold text-zinc-200">النمط الفني وهوية التصميم</label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {IMAGE_STYLES.map((style) => (
                <button
                  key={style.id}
                  type="button"
                  onClick={() => setSelectedStyle(style.id)}
                  className={`p-3 rounded-xl border text-right transition-all flex flex-col justify-between ${
                    selectedStyle === style.id
                      ? 'bg-[#d4af37]/15 border-[#d4af37] text-white'
                      : 'bg-zinc-950/60 border-zinc-800/80 text-zinc-300 hover:border-zinc-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold">{style.label}</span>
                    {selectedStyle === style.id && (
                      <Check className="w-3.5 h-3.5 text-[#f5d77f]" />
                    )}
                  </div>
                  <p className="text-[10px] text-zinc-400 mt-1 line-clamp-1">{style.desc}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Aspect Ratio & Quality Settings */}
          <div className="rounded-2xl bg-zinc-900/90 border border-zinc-800 p-4 space-y-4">
            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-200">أبعاد الصورة والمنصة المستهدفة</label>
              <div className="grid grid-cols-5 gap-2">
                {[
                  { ratio: '1:1', label: '1:1', desc: 'مربع انستغرام' },
                  { ratio: '9:16', label: '9:16', desc: 'ستوري وسناب' },
                  { ratio: '16:9', label: '16:9', desc: 'بانر ويوتيوب' },
                  { ratio: '4:3', label: '4:3', desc: 'بوست متوازن' },
                  { ratio: '3:4', label: '3:4', desc: 'بطاقة عمودية' },
                ].map((item) => (
                  <button
                    key={item.ratio}
                    type="button"
                    onClick={() => setAspectRatio(item.ratio as any)}
                    className={`p-2 rounded-xl border text-center transition-all ${
                      aspectRatio === item.ratio
                        ? 'bg-[#d4af37] text-zinc-950 font-bold border-[#d4af37]'
                        : 'bg-zinc-950 border-zinc-800 text-zinc-300 hover:border-zinc-700'
                    }`}
                  >
                    <div className="text-xs font-extrabold">{item.label}</div>
                    <div className="text-[9px] mt-0.5 truncate">{item.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-zinc-800/80">
              <span className="text-xs text-zinc-300 font-medium">جودة المعالجة والتصدير:</span>
              <div className="flex gap-2">
                {(['1080p', '2k', '4k'] as const).map((q) => (
                  <button
                    key={q}
                    type="button"
                    onClick={() => setQuality(q)}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                      quality === q
                        ? 'bg-[#d4af37]/20 border border-[#d4af37] text-[#f5d77f]'
                        : 'bg-zinc-800 text-zinc-400 hover:text-white'
                    }`}
                  >
                    {q.toUpperCase()}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Negative Prompt */}
          <div className="rounded-2xl bg-zinc-900/60 border border-zinc-800/80 p-3.5 space-y-2">
            <span className="text-[11px] font-semibold text-zinc-400 flex items-center gap-1">
              <Sliders className="w-3 h-3" />
              الكلمات المستبعدة (Negative Prompt)
            </span>
            <input
              type="text"
              value={negativePrompt}
              onChange={(e) => setNegativePrompt(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg px-3 py-1.5 text-xs text-zinc-300 focus:outline-none focus:border-zinc-700"
            />
          </div>

          {/* Generate Button */}
          <button
            type="button"
            onClick={handleGenerate}
            disabled={isGenerating || !prompt.trim()}
            className="w-full h-13 rounded-2xl bg-gradient-to-r from-[#d4af37] via-[#f5d77f] to-[#d4af37] text-[#09090b] font-black text-base flex items-center justify-center gap-2 shadow-xl shadow-[#d4af37]/20 hover:opacity-95 active:scale-[0.99] disabled:opacity-50 transition-all cursor-pointer"
          >
            {isGenerating ? (
              <>
                <RefreshCw className="w-5 h-5 animate-spin" />
                <span>جاري توليد التحفة الفنية...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                <span>توليد الصورة الآن بالذكاء الاصطناعي</span>
              </>
            )}
          </button>
        </div>

        {/* Right Column: Preview & Action Box */}
        <div className="lg:col-span-5 space-y-4">
          <div className="rounded-3xl bg-zinc-900/90 border border-zinc-800 p-4 shadow-2xl relative overflow-hidden">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Eye className="w-4 h-4 text-[#f5d77f]" />
                معاينة النتيجة المباشرة
              </span>
              <span className="text-[10px] text-zinc-400 font-mono">
                {quality.toUpperCase()} · {aspectRatio}
              </span>
            </div>

            {/* Canvas / Image Container */}
            <div className="mt-3 relative bg-zinc-950 rounded-2xl overflow-hidden min-h-[380px] flex items-center justify-center border border-zinc-800/80">
              {isGenerating ? (
                <div className="p-8 text-center space-y-5 max-w-sm">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#d4af37] to-[#f5d77f] mx-auto flex items-center justify-center animate-pulse shadow-lg shadow-[#d4af37]/30">
                    <Crown className="w-8 h-8 text-[#09090b]" />
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-bold text-sm text-white">إبداع الذكاء الاصطناعي قيد التنفيذ</h3>
                    <p className="text-xs text-zinc-400 leading-relaxed">{statusMessage}</p>
                  </div>
                  <div className="w-full bg-zinc-800 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-[#d4af37] to-[#f5d77f] h-full transition-all duration-300"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                  <span className="text-xs font-mono text-[#f5d77f]">{progress}%</span>
                </div>
              ) : generatedImage ? (
                <div className="w-full h-full relative group">
                  <img
                    src={generatedImage}
                    alt="Generated Luxury Art"
                    referrerPolicy="no-referrer"
                    className="w-full h-full max-h-[460px] object-contain rounded-xl"
                  />
                  <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-black/70 backdrop-blur-md border border-white/10 text-[10px] text-[#f5d77f] font-semibold">
                    جودة ملكية فائقة
                  </div>
                </div>
              ) : (
                <div className="text-center p-8 space-y-2 text-zinc-500">
                  <Sparkles className="w-8 h-8 mx-auto text-zinc-600" />
                  <p className="text-xs">اضغط على زر التوليد لبدء إنشاء تصميمك</p>
                </div>
              )}
            </div>

            {/* Actions Toolbar */}
            {generatedImage && !isGenerating && (
              <div className="mt-4 space-y-2.5">
                <button
                  type="button"
                  onClick={() => onOpenInEditor(generatedImage, prompt.slice(0, 28))}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#f5d77f] text-[#09090b] font-bold text-xs flex items-center justify-center gap-2 hover:opacity-95 shadow-md shadow-[#d4af37]/20"
                >
                  <Edit3 className="w-4 h-4" />
                  <span>فتح في محرر التصاميم (إضافة نصوص وتعديل)</span>
                </button>

                <div className="grid grid-cols-2 gap-2">
                  <a
                    href={generatedImage}
                    download="فخامة_التصميم_AI.jpg"
                    className="py-2 px-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Download className="w-4 h-4 text-[#f5d77f]" />
                    <span>تنزيل عالي الدقة</span>
                  </a>

                  <button
                    type="button"
                    onClick={handleSave}
                    className="py-2 px-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors"
                  >
                    {savedSuccess ? (
                      <>
                        <Check className="w-4 h-4 text-emerald-400" />
                        <span className="text-emerald-400">تم الحفظ بالمعرض</span>
                      </>
                    ) : (
                      <>
                        <Bookmark className="w-4 h-4 text-[#f5d77f]" />
                        <span>حفظ في المعرض</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
