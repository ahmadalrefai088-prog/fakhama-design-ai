import React, { useState } from 'react';
import {
  User,
  Crown,
  Smartphone,
  Sparkles,
  Settings,
  HardDrive,
  Download,
  CheckCircle2,
  Sliders,
  ShieldCheck,
  ChevronLeft,
  RefreshCw,
  ExternalLink,
  Code
} from 'lucide-react';

interface ProfileSettingsProps {
  savedDesignsCount: number;
}

export const ProfileSettings: React.FC<ProfileSettingsProps> = ({ savedDesignsCount }) => {
  const [defaultFont, setDefaultFont] = useState('Amiri');
  const [exportQuality, setExportQuality] = useState('4k');
  const [autoSave, setAutoSave] = useState(true);
  const [clearedCache, setClearedCache] = useState(false);
  const [installedPWA, setInstalledPWA] = useState(false);

  const handleClearCache = () => {
    setClearedCache(true);
    setTimeout(() => setClearedCache(false), 2500);
  };

  const handleInstallApp = () => {
    setInstalledPWA(true);
    setTimeout(() => setInstalledPWA(false), 3000);
  };

  return (
    <div className="space-y-6 pb-12 animate-fade-in max-w-4xl mx-auto">
      {/* Header */}
      <div className="border-b border-zinc-800 pb-4">
        <h1 className="text-2xl font-black text-white flex items-center gap-2">
          <User className="w-6 h-6 text-[#f5d77f]" />
          الملف الشخصي وإعدادات تطبيق أندرويد
        </h1>
        <p className="text-xs text-zinc-400 mt-1">
          تطبيق مجاني بدون إعلانات أو اشتراكات، مع خيارات جودة التصدير والتثبيت على أندرويد
        </p>
      </div>

      {/* Free User Profile Card */}
      <div className="rounded-3xl bg-gradient-to-br from-[#18181d] via-[#121216] to-[#09090b] border border-[#d4af37]/40 p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-64 h-64 bg-[#d4af37]/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col sm:flex-row items-center sm:items-start gap-5 text-center sm:text-right">
          {/* Avatar */}
          <div className="relative">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-[#d4af37] via-[#f5d77f] to-[#aa8022] p-1 shadow-xl shadow-[#d4af37]/25">
              <div className="w-full h-full bg-[#09090b] rounded-[14px] flex items-center justify-center text-2xl font-black text-[#f5d77f]">
                أ
              </div>
            </div>
            <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-[#d4af37] flex items-center justify-center text-zinc-950 shadow-md">
              <Crown className="w-3.5 h-3.5" />
            </div>
          </div>

          {/* Details */}
          <div className="space-y-1.5 flex-1">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h2 className="text-xl font-black text-white">أحمد الرفاعي</h2>
                <p className="text-xs text-zinc-400 font-mono mt-0.5">نسخة مجانية</p>
              </div>

              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#d4af37]/15 border border-[#d4af37]/40 text-xs text-[#f5d77f] font-bold self-center sm:self-auto">
                <Crown className="w-3.5 h-3.5" />
                <span>فخامة التصميم – مجاني</span>
              </span>
            </div>

            <p className="text-xs text-zinc-300 pt-2 leading-relaxed font-light">
              استخدم أدوات التصميم المتاحة في التطبيق دون اشتراك أو دفع. قد تتطلب بعض ميزات الذكاء الاصطناعي اتصالاً بخدمة خارجية ومفتاح API.
            </p>

            <div className="pt-3 flex flex-wrap items-center justify-center sm:justify-start gap-4 text-xs text-zinc-400">
              <span className="flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> الحساب نشط ومعتمد
              </span>
              <span>·</span>
              <span>عدد المشاريع: {savedDesignsCount}</span>
              <span>·</span>
              <span>تاريخ الانضمام: 2026</span>
            </div>
          </div>
        </div>
      </div>

      {/* Android APK & PWA Installation Section */}
      <div className="rounded-2xl bg-zinc-900/90 border border-zinc-800 p-6 space-y-4 shadow-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-emerald-950/60 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">تثبيت التطبيق على هاتف أندرويد (APK / PWA)</h3>
              <p className="text-xs text-zinc-400">
                استمتع بالتطبيق بملء الشاشة على هاتفك تماماً كتطبيق أصلي (Native App)
              </p>
            </div>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-3">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="space-y-1 text-right">
              <span className="text-xs font-bold text-zinc-200">
                تثبيت فوري على شاشة الهاتف الرئيسية
              </span>
              <p className="text-[11px] text-zinc-400">
                يعمل بدون إنترنت جزئياً ويفتح مباشرة بلمسة زر واحدة بدون شريط المتصفح
              </p>
            </div>

            <button
              onClick={handleInstallApp}
              className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#f5d77f] text-[#09090b] font-bold text-xs flex items-center justify-center gap-2 shadow-sm shadow-[#d4af37]/20 hover:opacity-95"
            >
              {installedPWA ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-950" />
                  <span>تم التثبيت على شاشة الهاتف!</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  <span>تثبيت كتطبيق أندرويد الآن</span>
                </>
              )}
            </button>
          </div>

          <div className="pt-3 border-t border-zinc-800 text-xs text-zinc-400 space-y-2">
            <span className="font-bold text-zinc-300 block flex items-center gap-1.5">
              <Code className="w-3.5 h-3.5 text-[#f5d77f]" />
              للمطورين: تحويل المشروع إلى تطبيق أندرويد APK عبر Capacitor:
            </span>
            <div className="p-2.5 rounded-lg bg-zinc-900 border border-zinc-800/80 font-mono text-[11px] text-zinc-300 overflow-x-auto text-left" dir="ltr">
              npm install @capacitor/core @capacitor/cli @capacitor/android<br />
              npx cap init "فخامة التصميم AI" com.fakhamat.design<br />
              npm run build && npx cap add android && npx cap run android
            </div>
          </div>
        </div>
      </div>

      {/* Preferences & Resolution Settings */}
      <div className="rounded-2xl bg-zinc-900/90 border border-zinc-800 p-6 space-y-4 shadow-xl">
        <h3 className="font-bold text-sm text-white flex items-center gap-2">
          <Settings className="w-4 h-4 text-[#f5d77f]" />
          تفضيلات التصدير والجودة الافتراضية
        </h3>

        <div className="space-y-4 text-xs">
          {/* Quality */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-zinc-800">
            <div>
              <span className="font-bold text-zinc-200">دقة التصدير والتنزيل الافتراضية:</span>
              <p className="text-[11px] text-zinc-400 mt-0.5">
                تحديد دقة ملفات PNG وJPEG الناتجة من المحرر والمولد
              </p>
            </div>
            <div className="flex gap-2">
              {[
                { id: '1080p', label: '1080p FHD' },
                { id: '2k', label: '2K QHD' },
                { id: '4k', label: '4K Ultra Gold' },
              ].map((q) => (
                <button
                  key={q.id}
                  onClick={() => setExportQuality(q.id)}
                  className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                    exportQuality === q.id
                      ? 'bg-[#d4af37] text-zinc-950 shadow-sm'
                      : 'bg-zinc-800 text-zinc-400 hover:text-white'
                  }`}
                >
                  {q.label}
                </button>
              ))}
            </div>
          </div>

          {/* Default Font */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-zinc-800">
            <div>
              <span className="font-bold text-zinc-200">الخط العربي الافتراضي للمحرر:</span>
              <p className="text-[11px] text-zinc-400 mt-0.5">
                الخط الذي يتم اختياره تلقائياً عند إضافة طبقة جديدة
              </p>
            </div>
            <div className="flex gap-2">
              {[
                { id: 'Amiri', label: 'الأميري الملكي' },
                { id: 'Cairo', label: 'القاهرة العصري' },
                { id: 'Tajawal', label: 'تجوّل الأنيق' },
              ].map((f) => (
                <button
                  key={f.id}
                  onClick={() => setDefaultFont(f.id)}
                  className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                    defaultFont === f.id
                      ? 'bg-[#d4af37]/20 border border-[#d4af37] text-[#f5d77f]'
                      : 'bg-zinc-800 text-zinc-400 hover:text-white'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {/* Storage & Cache */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <span className="font-bold text-zinc-200">الذاكرة التخزينية المحلية:</span>
              <p className="text-[11px] text-zinc-400 mt-0.5">
                مساحة تصاميمك المحفوظة داخل متصفح جهازك
              </p>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-zinc-400 text-[11px] font-mono">14.2 MB / 5.0 GB</span>
              <button
                onClick={handleClearCache}
                className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-semibold transition-colors"
              >
                {clearedCache ? 'تم المسح بنجاح' : 'تفريغ الكاش'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Architecture and Security Notice */}
      <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800/80 text-xs text-zinc-400 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>الأمان والخصوصية: لا يتم حفظ أو مشاركة أي مفاتيح سرية في الكلاينت.</span>
        </div>
        <span className="font-mono text-[10px] text-zinc-500">v1.0.0 Royal Edition</span>
      </div>
    </div>
  );
};
