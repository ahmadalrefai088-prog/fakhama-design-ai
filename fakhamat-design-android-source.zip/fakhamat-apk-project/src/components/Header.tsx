import React from 'react';
import { Crown, Sparkles, User, Palette } from 'lucide-react';
import { ActiveTab } from '../types';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  savedCount: number;
}

export const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab, savedCount }) => {
  return (
    <header className="sticky top-0 z-40 bg-[#09090b]/90 backdrop-blur-md border-b border-[#27272a]/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        {/* Brand Zone: 1 Single line wordmark */}
        <div
          onClick={() => setActiveTab('home')}
          className="flex items-center gap-2.5 cursor-pointer select-none group shrink-0"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#f5d77f] via-[#d4af37] to-[#aa8022] p-0.5 shadow-md shadow-[#d4af37]/20 group-hover:scale-105 transition-transform duration-200">
            <div className="w-full h-full bg-[#09090b] rounded-[10px] flex items-center justify-center">
              <Crown className="w-5 h-5 text-[#f5d77f]" />
            </div>
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-extrabold tracking-tight text-white group-hover:text-[#f5d77f] transition-colors whitespace-nowrap">
              فخامة التصميم <span className="text-gold-gradient font-black">AI</span>
            </span>
            <span className="text-[10px] text-zinc-400 font-medium tracking-wide hidden sm:inline whitespace-nowrap">
              استوديو الذكاء الاصطناعي الفاخر
            </span>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1 xl:gap-2 text-sm font-medium text-zinc-300">
          <button
            onClick={() => setActiveTab('home')}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'home'
                ? 'bg-zinc-800 text-[#f5d77f] font-bold'
                : 'hover:text-white hover:bg-zinc-800/60'
            }`}
          >
            الرئيسية
          </button>
          <button
            onClick={() => setActiveTab('generator')}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'generator'
                ? 'bg-zinc-800 text-[#f5d77f] font-bold'
                : 'hover:text-white hover:bg-zinc-800/60'
            }`}
          >
            توليد الصور
          </button>
          <button
            onClick={() => setActiveTab('templates')}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'templates'
                ? 'bg-zinc-800 text-[#f5d77f] font-bold'
                : 'hover:text-white hover:bg-zinc-800/60'
            }`}
          >
            القوالب الجاهزة
          </button>
          <button
            onClick={() => setActiveTab('editor')}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'editor'
                ? 'bg-zinc-800 text-[#f5d77f] font-bold'
                : 'hover:text-white hover:bg-zinc-800/60'
            }`}
          >
            محرر التصاميم
          </button>
          <button
            onClick={() => setActiveTab('copywriter')}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'copywriter'
                ? 'bg-zinc-800 text-[#f5d77f] font-bold'
                : 'hover:text-white hover:bg-zinc-800/60'
            }`}
          >
            المساعد الذكي
          </button>
          <button
            onClick={() => setActiveTab('logo')}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'logo'
                ? 'bg-zinc-800 text-[#f5d77f] font-bold'
                : 'hover:text-white hover:bg-zinc-800/60'
            }`}
          >
            الشعارات
          </button>
          <button
            onClick={() => setActiveTab('video')}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'video'
                ? 'bg-zinc-800 text-[#f5d77f] font-bold'
                : 'hover:text-white hover:bg-zinc-800/60'
            }`}
          >
            الفيديو
          </button>
          <button
            onClick={() => setActiveTab('bgremover')}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'bgremover'
                ? 'bg-zinc-800 text-[#f5d77f] font-bold'
                : 'hover:text-white hover:bg-zinc-800/60'
            }`}
          >
            إزالة الخلفية
          </button>
          <button
            onClick={() => setActiveTab('gallery')}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'gallery'
                ? 'bg-zinc-800 text-[#f5d77f] font-bold'
                : 'hover:text-white hover:bg-zinc-800/60'
            }`}
          >
            <span>المعرض</span>
            {savedCount > 0 && (
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-[#d4af37]/20 text-[#f5d77f] border border-[#d4af37]/30">
                {savedCount}
              </span>
            )}
          </button>
        </nav>

        {/* Action Zone: VIP Status & Profile Trigger */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div className="hidden sm:flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900 border border-[#d4af37]/30 text-xs">
            <Sparkles className="w-3.5 h-3.5 text-[#f5d77f]" />
            <span className="text-[#f5d77f] font-bold">نسخة مجانية</span>
          </div>

          <button
            onClick={() => setActiveTab('profile')}
            className={`h-10 px-3 rounded-xl border flex items-center gap-2 transition-all ${
              activeTab === 'profile'
                ? 'bg-[#d4af37]/20 border-[#d4af37] text-white shadow-sm shadow-[#d4af37]/20'
                : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:border-zinc-700 hover:text-white'
            }`}
            title="الملف الشخصي والإعدادات"
          >
            <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-[#d4af37] to-[#f5d77f] flex items-center justify-center text-[#09090b] font-bold text-xs">
              أ
            </div>
            <span className="text-xs font-semibold hidden md:inline">أحمد الرفاعي</span>
          </button>
        </div>
      </div>
    </header>
  );
};
