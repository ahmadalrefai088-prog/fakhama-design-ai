import React, { useState } from 'react';
import {
  Bookmark,
  Search,
  Download,
  Edit3,
  Trash2,
  Eye,
  Plus,
  Share2,
  Calendar,
  Sparkles,
  X
} from 'lucide-react';
import { SavedDesign, ActiveTab } from '../types';

interface DesignGalleryProps {
  designs: SavedDesign[];
  onOpenDesignInEditor: (design: SavedDesign) => void;
  onDeleteDesign: (id: string) => void;
  setActiveTab: (tab: ActiveTab) => void;
}

export const DesignGallery: React.FC<DesignGalleryProps> = ({
  designs,
  onOpenDesignInEditor,
  onDeleteDesign,
  setActiveTab,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeModalDesign, setActiveModalDesign] = useState<SavedDesign | null>(null);

  const categories = [
    { id: 'all', label: 'كافة التصاميم' },
    { id: 'image', label: 'صور الذكاء الاصطناعي' },
    { id: 'template', label: 'قوالب معدلة' },
    { id: 'logo', label: 'شعارات ملكية' },
    { id: 'custom', label: 'تصاميم مخصصة' },
  ];

  const filtered = designs.filter((d) => {
    const matchesCat = selectedCategory === 'all' || d.category === selectedCategory;
    const matchesSearch =
      d.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  return (
    <div className="space-y-6 pb-12 animate-fade-in max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-800 pb-4">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <Bookmark className="w-6 h-6 text-[#f5d77f]" />
            معرض تصاميمي ومشاريعي السابقة
          </h1>
          <p className="text-xs text-zinc-400 mt-1">
            جميع أعمالك الفاخرة محفوظة محلياً وجاهزة لإعادة التعديل والتحميل في أي وقت
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Search */}
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث في تصاميمك..."
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl pr-9 pl-3 py-2 text-xs text-zinc-200 placeholder:text-zinc-500 focus:outline-none focus:border-[#d4af37]"
            />
          </div>

          <button
            onClick={() => setActiveTab('editor')}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#f5d77f] text-[#09090b] font-bold text-xs flex items-center gap-1.5 shadow-sm shadow-[#d4af37]/20 hover:opacity-95 shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">تصميم جديد</span>
          </button>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap shrink-0 ${
              selectedCategory === cat.id
                ? 'bg-gradient-to-r from-[#d4af37] to-[#f5d77f] text-[#09090b] shadow-md shadow-[#d4af37]/20'
                : 'bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Grid of Saved Designs */}
      {filtered.length === 0 ? (
        <div className="rounded-3xl bg-zinc-900/60 border border-zinc-800 p-12 text-center space-y-4 max-w-md mx-auto my-8">
          <div className="w-16 h-16 rounded-2xl bg-zinc-800 flex items-center justify-center mx-auto text-[#f5d77f]">
            <Bookmark className="w-8 h-8" />
          </div>
          <h3 className="font-bold text-base text-white">لا توجد تصاميم مطابقة في المعرض</h3>
          <p className="text-xs text-zinc-400">
            ابدأ بتوليد الصور بالذكاء الاصطناعي أو اختر من القوالب الجاهزة لحفظها هنا
          </p>
          <button
            onClick={() => setActiveTab('generator')}
            className="px-5 py-2.5 rounded-xl bg-[#d4af37] text-zinc-950 font-bold text-xs inline-flex items-center gap-1.5 hover:opacity-95"
          >
            <Sparkles className="w-4 h-4" />
            <span>توليد تصميمك الأول</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {filtered.map((design) => (
            <div
              key={design.id}
              className="group rounded-2xl bg-[#121216] border border-zinc-800 hover:border-[#d4af37]/40 overflow-hidden shadow-xl flex flex-col justify-between transition-all hover:-translate-y-1"
            >
              {/* Thumbnail */}
              <div className="relative aspect-square bg-zinc-950 overflow-hidden">
                <img
                  src={design.thumbnail}
                  alt={design.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />

                <div className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded-md bg-black/75 backdrop-blur-md text-[10px] font-mono text-[#f5d77f] border border-white/10">
                  {design.aspectRatio}
                </div>

                {/* Hover overlay quick action */}
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                  <button
                    onClick={() => setActiveModalDesign(design)}
                    className="p-2 rounded-full bg-white/20 backdrop-blur-md hover:bg-white/30 text-white"
                    title="معاينة"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onOpenDesignInEditor(design)}
                    className="p-2 rounded-full bg-[#d4af37] text-[#09090b] hover:opacity-95 font-bold"
                    title="تعديل في المحرر"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Info & Footer */}
              <div className="p-3.5 space-y-2.5">
                <div>
                  <h4 className="font-bold text-xs text-white truncate" title={design.title}>
                    {design.title}
                  </h4>
                  <div className="flex items-center gap-1.5 text-[10px] text-zinc-400 mt-1">
                    <Calendar className="w-3 h-3 text-zinc-500" />
                    <span>{design.createdAt}</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-zinc-800/80 flex items-center justify-between">
                  <button
                    onClick={() => onOpenDesignInEditor(design)}
                    className="text-xs text-[#f5d77f] font-bold hover:underline flex items-center gap-1"
                  >
                    <Edit3 className="w-3 h-3" />
                    <span>تعديل</span>
                  </button>

                  <div className="flex items-center gap-1">
                    <a
                      href={design.thumbnail}
                      download={`${design.title}.png`}
                      className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white transition-colors"
                      title="تنزيل"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </a>

                    <button
                      onClick={() => onDeleteDesign(design.id)}
                      className="p-1.5 rounded-lg bg-zinc-800 hover:bg-red-950/60 text-zinc-400 hover:text-red-400 transition-colors"
                      title="حذف"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal Inspector */}
      {activeModalDesign && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in"
          onClick={() => setActiveModalDesign(null)}
        >
          <div
            className="w-full max-w-xl bg-[#121216] border border-zinc-800 rounded-3xl p-6 shadow-2xl space-y-5"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <h3 className="font-bold text-base text-white truncate">{activeModalDesign.title}</h3>
              <button
                onClick={() => setActiveModalDesign(null)}
                className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center text-zinc-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="relative max-h-[50vh] bg-zinc-950 rounded-2xl overflow-hidden flex items-center justify-center">
              <img
                src={activeModalDesign.thumbnail}
                alt={activeModalDesign.title}
                referrerPolicy="no-referrer"
                className="max-h-[45vh] object-contain rounded-xl"
              />
            </div>

            <div className="flex items-center gap-3 pt-2 border-t border-zinc-800">
              <button
                onClick={() => {
                  onOpenDesignInEditor(activeModalDesign);
                  setActiveModalDesign(null);
                }}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#f5d77f] text-[#09090b] font-bold text-xs flex items-center justify-center gap-1.5"
              >
                <Edit3 className="w-4 h-4" />
                <span>فتح وتعديل في المحرر</span>
              </button>

              <a
                href={activeModalDesign.thumbnail}
                download={`${activeModalDesign.title}.png`}
                className="px-4 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-semibold text-xs flex items-center gap-1.5"
              >
                <Download className="w-4 h-4 text-[#f5d77f]" />
                <span>تنزيل</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
