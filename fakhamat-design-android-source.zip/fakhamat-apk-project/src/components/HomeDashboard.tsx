import React from 'react';
import {
  Sparkles,
  LayoutGrid,
  Edit3,
  PenTool,
  Award,
  Video,
  Scissors,
  Bookmark,
  ArrowLeft,
  Crown,
  ChevronLeft,
  CheckCircle2,
  Clock,
  Download
} from 'lucide-react';
import { ActiveTab, DesignTemplate, SavedDesign } from '../types';
import { INITIAL_TEMPLATES } from '../data/initialData';

interface HomeDashboardProps {
  setActiveTab: (tab: ActiveTab) => void;
  savedDesigns: SavedDesign[];
  onOpenTemplateInEditor: (template: DesignTemplate) => void;
  onOpenDesignInEditor: (design: SavedDesign) => void;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  setActiveTab,
  savedDesigns,
  onOpenTemplateInEditor,
  onOpenDesignInEditor,
}) => {
  const quickTools = [
    {
      tab: 'generator' as ActiveTab,
      title: 'إنشاء الصور بالذكاء الاصطناعي',
      desc: 'صمم لوحات وإعلانات سينمائية بلمسة ذهب ملكية',
      icon: Sparkles,
      color: 'from-[#d4af37]/20 to-amber-950/30',
      borderColor: 'border-[#d4af37]/40',
      badge: 'فائق الدقة 4K',
    },
    {
      tab: 'templates' as ActiveTab,
      title: 'قوالب جاهزة فاخرة',
      desc: 'دعوات زفاف راقية، تهاني الأعياد، وإعلانات تجارية',
      icon: LayoutGrid,
      color: 'from-amber-900/20 to-zinc-900',
      borderColor: 'border-zinc-800',
      badge: 'جاهزة للطباعة',
    },
    {
      tab: 'editor' as ActiveTab,
      title: 'محرر التصاميم الحي',
      desc: 'أضف نصوصاً عربية بخطوط الثلث والكوفي وعدّل الطبقات',
      icon: Edit3,
      color: 'from-zinc-800 to-zinc-900',
      borderColor: 'border-zinc-700',
      badge: 'تعديل مرن',
    },
    {
      tab: 'copywriter' as ActiveTab,
      title: 'مساعد النصوص وتصحيح الإملاء',
      desc: 'صياغة إعلانات تسويقية وتدقيق إملائي ونحوي دقيق',
      icon: PenTool,
      color: 'from-amber-950/20 to-zinc-900',
      borderColor: 'border-zinc-800',
      badge: 'مدعوم بـ Gemini',
    },
    {
      tab: 'logo' as ActiveTab,
      title: 'مصمم الشعارات الملكية',
      desc: 'أنشئ مونوغرامات وتيجان ذهبية مع موك اب واقعي',
      icon: Award,
      color: 'from-[#d4af37]/20 to-zinc-900',
      borderColor: 'border-[#d4af37]/30',
      badge: 'موك اب 3D',
    },
    {
      tab: 'video' as ActiveTab,
      title: 'أستوديو الفيديو والموشن ستوري',
      desc: 'اصنع قصصاً متحركة للأعياد والأعراس برذاذ الذهب',
      icon: Video,
      color: 'from-zinc-800 to-zinc-900',
      borderColor: 'border-zinc-800',
      badge: 'ستوري 9:16',
    },
    {
      tab: 'bgremover' as ActiveTab,
      title: 'أداة تفريغ خلفية الصور',
      desc: 'عزل فوري للمنتجات بدقة عالية وتصديرها بصيغة PNG',
      icon: Scissors,
      color: 'from-zinc-800 to-zinc-900',
      borderColor: 'border-zinc-800',
      badge: 'تفريغ ذكي',
    },
    {
      tab: 'gallery' as ActiveTab,
      title: 'معرض تصاميمي السابقة',
      desc: 'استعرض وحمل كافة أعمالك بجودتها الكاملة بأي وقت',
      icon: Bookmark,
      color: 'from-zinc-800 to-zinc-900',
      borderColor: 'border-zinc-800',
      badge: `${savedDesigns.length} تصاميم`,
    },
  ];

  return (
    <div className="space-y-8 pb-12 animate-fade-in">
      {/* Hero Banner with VIP Greeting */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#18181b] via-[#121216] to-[#09090b] border border-[#d4af37]/30 p-6 md:p-10 shadow-2xl">
        {/* Subtle Luxury Pattern Accents */}
        <div className="absolute top-0 left-0 w-80 h-80 bg-[#d4af37]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 right-0 w-64 h-64 bg-amber-600/5 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#d4af37]/15 border border-[#d4af37]/40 text-xs text-[#f5d77f]">
              <Crown className="w-3.5 h-3.5" />
              <span className="font-bold">استوديو التصميم العربي الفاخر</span>
            </div>

            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white leading-tight">
              أهلاً بك، <span className="text-gold-gradient">أحمد الرفاعي</span> في فخامة التصميم
            </h1>

            <p className="text-sm sm:text-base text-zinc-300 leading-relaxed font-light">
              منصتك المتكاملة لتصميم أرقى الإعلانات، دعوات الزفاف الملكية، وبطاقات التهاني والشعارات
              بأعلى معايير الإتقان، بدعم كامل للغة العربية والذكاء الاصطناعي.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => setActiveTab('generator')}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#f5d77f] text-[#09090b] font-bold text-sm flex items-center gap-2 shadow-lg shadow-[#d4af37]/25 hover:scale-[1.02] active:scale-[0.98] transition-all"
              >
                <Sparkles className="w-4 h-4" />
                <span>ابدأ توليد الصور بالذكاء الاصطناعي</span>
              </button>

              <button
                onClick={() => setActiveTab('templates')}
                className="px-5 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-zinc-200 font-semibold text-sm hover:border-[#d4af37]/40 hover:text-white transition-all flex items-center gap-2"
              >
                <LayoutGrid className="w-4 h-4 text-[#f5d77f]" />
                <span>استكشاف القوالب الجاهزة</span>
              </button>
            </div>
          </div>

          {/* Quick Stats / Free version badge */}
          <div className="lg:w-80 p-5 rounded-2xl bg-zinc-900/90 border border-zinc-800 shadow-xl space-y-4 shrink-0">
            <div className="flex items-center justify-between">
              <span className="text-xs text-zinc-400">حالة الحساب</span>
              <span className="text-xs font-bold text-[#f5d77f] flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> نسخة مجانية
              </span>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-xs text-zinc-300">
                <span>توليد الصور الفائق</span>
                <span className="font-bold text-[#f5d77f]">متاح دائماً</span>
              </div>
              <div className="w-full bg-zinc-800 h-1.5 rounded-full overflow-hidden">
                <div className="bg-gradient-to-r from-[#d4af37] to-[#f5d77f] h-full w-[85%]" />
              </div>
            </div>

            <div className="pt-2 border-t border-zinc-800/80 flex items-center justify-between text-xs text-zinc-400">
              <div className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-zinc-500" />
                <span>التصاميم المحفوظة: {savedDesigns.length}</span>
              </div>
              <button
                onClick={() => setActiveTab('gallery')}
                className="text-[#f5d77f] hover:underline font-semibold"
              >
                فتح المعرض ←
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 8 Core Tools Grid */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Crown className="w-5 h-5 text-[#f5d77f]" />
              أدوات الاستوديو الملكية
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              كل ما تحتاجه لصناعة المحتوى البصري الفاخر في مكان واحد
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickTools.map((tool) => {
            const Icon = tool.icon;
            return (
              <div
                key={tool.tab}
                onClick={() => setActiveTab(tool.tab)}
                className={`group p-5 rounded-2xl bg-gradient-to-br ${tool.color} border ${tool.borderColor} hover:border-[#d4af37]/60 cursor-pointer transition-all duration-300 hover:-translate-y-1 shadow-lg relative flex flex-col justify-between`}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="w-11 h-11 rounded-xl bg-zinc-950/80 border border-zinc-800 group-hover:border-[#d4af37]/50 flex items-center justify-center text-[#f5d77f] transition-colors shadow-inner">
                      <Icon className="w-5 h-5 group-hover:scale-110 transition-transform" />
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-zinc-900/90 text-zinc-300 border border-zinc-800">
                      {tool.badge}
                    </span>
                  </div>

                  <div>
                    <h3 className="font-bold text-base text-white group-hover:text-[#f5d77f] transition-colors">
                      {tool.title}
                    </h3>
                    <p className="text-xs text-zinc-400 mt-1 line-clamp-2 leading-relaxed">
                      {tool.desc}
                    </p>
                  </div>
                </div>

                <div className="pt-4 mt-3 border-t border-zinc-800/60 flex items-center justify-between text-xs font-semibold text-zinc-400 group-hover:text-white">
                  <span>فتح الأداة</span>
                  <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform text-[#f5d77f]" />
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Featured Ready-Made Templates */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <LayoutGrid className="w-5 h-5 text-[#f5d77f]" />
              أحدث القوالب الفاخرة الجاهزة
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              نماذج راقية يمكنك فتحها والتعديل عليها مباشرة بنقرة واحدة
            </p>
          </div>

          <button
            onClick={() => setActiveTab('templates')}
            className="text-xs text-[#f5d77f] hover:underline font-bold flex items-center gap-1"
          >
            <span>عرض كل القوالب ({INITIAL_TEMPLATES.length})</span>
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {INITIAL_TEMPLATES.slice(0, 3).map((template) => (
            <div
              key={template.id}
              className="group rounded-2xl bg-[#121216] border border-zinc-800 hover:border-[#d4af37]/40 overflow-hidden shadow-xl flex flex-col justify-between transition-all"
            >
              <div className="relative aspect-[4/3] bg-zinc-950 overflow-hidden">
                <img
                  src={template.thumbnail}
                  alt={template.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-black/75 backdrop-blur-md border border-white/10 text-[11px] font-semibold text-[#f5d77f]">
                  {template.categoryLabel}
                </div>
              </div>

              <div className="p-4 space-y-3">
                <div>
                  <h3 className="font-bold text-base text-white group-hover:text-[#f5d77f] transition-colors">
                    {template.title}
                  </h3>
                  <p className="text-xs text-zinc-400 mt-1 line-clamp-2">
                    {template.description}
                  </p>
                </div>

                <div className="flex items-center gap-2 pt-2 border-t border-zinc-800">
                  <button
                    onClick={() => onOpenTemplateInEditor(template)}
                    className="flex-1 py-2 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#f5d77f] text-[#09090b] text-xs font-bold flex items-center justify-center gap-1.5 hover:opacity-90 transition-opacity"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>تعديل في المحرر</span>
                  </button>

                  <a
                    href={template.thumbnail}
                    download={`${template.title}.jpg`}
                    className="p-2 rounded-xl bg-zinc-800 text-zinc-300 hover:text-white hover:bg-zinc-700 transition-colors"
                    title="تنزيل القالب"
                  >
                    <Download className="w-4 h-4" />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Recent Designs Quick Access */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Bookmark className="w-5 h-5 text-[#f5d77f]" />
              تصاميمي السابقة
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              مشاريعك المحفوظة مؤخراً جاهزة للتحميل أو المتابعة
            </p>
          </div>

          <button
            onClick={() => setActiveTab('gallery')}
            className="text-xs text-[#f5d77f] hover:underline font-bold flex items-center gap-1"
          >
            <span>إدارة المعرض</span>
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {savedDesigns.slice(0, 4).map((design) => (
            <div
              key={design.id}
              onClick={() => onOpenDesignInEditor(design)}
              className="group rounded-2xl bg-zinc-900/90 border border-zinc-800 hover:border-[#d4af37]/40 overflow-hidden cursor-pointer transition-all hover:-translate-y-1"
            >
              <div className="aspect-square bg-zinc-950 overflow-hidden relative">
                <img
                  src={design.thumbnail}
                  alt={design.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-2.5">
                  <span className="text-[11px] font-bold text-[#f5d77f] flex items-center gap-1">
                    <Edit3 className="w-3 h-3" /> فتح للتعديل
                  </span>
                </div>
              </div>
              <div className="p-3">
                <h4 className="text-xs font-bold text-white truncate">{design.title}</h4>
                <p className="text-[10px] text-zinc-400 mt-0.5">{design.createdAt}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
