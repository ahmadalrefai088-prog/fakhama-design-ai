import React, { useState, useEffect, useRef } from 'react';
import {
  Video,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Sparkles,
  Download,
  Film,
  Crown,
  Share2,
  Edit3,
  Sliders,
  Check
} from 'lucide-react';
import { VIDEO_PRESETS } from '../data/initialData';

interface VideoStudioProps {
  onOpenInEditor: (imageUrl: string, title: string) => void;
}

export const VideoStudio: React.FC<VideoStudioProps> = ({ onOpenInEditor }) => {
  const [selectedPreset, setSelectedPreset] = useState(VIDEO_PRESETS[0]);
  const [isPlaying, setIsPlaying] = useState(true);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(selectedPreset.duration);
  const [audioEnabled, setAudioEnabled] = useState(false);
  const [motionEffect, setMotionEffect] = useState<'shimmer' | 'zoom' | 'sparks'>('sparks');
  const [headline, setHeadline] = useState(selectedPreset.headline);
  const [subline, setSubline] = useState(selectedPreset.subline);
  const [exportSuccess, setExportSuccess] = useState(false);

  const audioCtxRef = useRef<AudioContext | null>(null);

  // Play ambient luxury tone using Web Audio API
  const playLuxuryChime = () => {
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }

      // Elegant chime pentatonic frequencies
      const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.25);
        gain.gain.setValueAtTime(0.08, ctx.currentTime + idx * 0.25);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + idx * 0.25 + 1.2);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + idx * 0.25);
        osc.stop(ctx.currentTime + idx * 0.25 + 1.5);
      });
    } catch (e) {
      console.warn('Web Audio error:', e);
    }
  };

  // Video playback loop
  useEffect(() => {
    let interval: any = null;
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTime((prev) => {
          if (prev >= duration) {
            if (audioEnabled) playLuxuryChime();
            return 0;
          }
          return Number((prev + 0.1).toFixed(1));
        });
      }, 100);
    }
    return () => clearInterval(interval);
  }, [isPlaying, duration, audioEnabled]);

  // Update preset
  const handleSelectPreset = (preset: typeof VIDEO_PRESETS[0]) => {
    setSelectedPreset(preset);
    setHeadline(preset.headline);
    setSubline(preset.subline);
    setDuration(preset.duration);
    setCurrentTime(0);
    setIsPlaying(true);
  };

  const handleExport = () => {
    setExportSuccess(true);
    setTimeout(() => setExportSuccess(false), 3000);
  };

  return (
    <div className="space-y-6 pb-12 animate-fade-in max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-800 pb-4">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <Video className="w-6 h-6 text-[#f5d77f]" />
            أستوديو تصميم الفيديوهات والقصص المتحركة (Motion Studio)
          </h1>
          <p className="text-xs text-zinc-400 mt-1">
            صمم ستوري وقصص ريلز متحركة 9:16 ببريق الذهب والتأثيرات السينمائية الجذابة
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#f5d77f] text-[#09090b] font-bold text-xs flex items-center gap-1.5 shadow-sm shadow-[#d4af37]/20 hover:opacity-95"
          >
            {exportSuccess ? (
              <>
                <Check className="w-4 h-4 text-emerald-950" />
                <span>تم تجهيز الفيديو بنجاح!</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>تصدير فيديو عالي الدقة (MP4/Story)</span>
              </>
            )}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Preset Templates & Settings */}
        <div className="lg:col-span-6 space-y-4">
          <div className="rounded-2xl bg-zinc-900/90 border border-zinc-800 p-5 space-y-4 shadow-xl">
            <label className="text-xs font-bold text-zinc-200 flex items-center gap-1.5">
              <Film className="w-4 h-4 text-[#f5d77f]" />
              نماذج القصص المتحركة الجاهزة:
            </label>

            <div className="space-y-2.5">
              {VIDEO_PRESETS.map((preset) => (
                <div
                  key={preset.id}
                  onClick={() => handleSelectPreset(preset)}
                  className={`p-3 rounded-2xl border text-right cursor-pointer transition-all flex items-center gap-3 ${
                    selectedPreset.id === preset.id
                      ? 'bg-[#d4af37]/15 border-[#d4af37] text-white shadow-md'
                      : 'bg-zinc-950 border-zinc-800 text-zinc-300 hover:border-zinc-700'
                  }`}
                >
                  <img
                    src={preset.image}
                    alt={preset.title}
                    referrerPolicy="no-referrer"
                    className="w-14 h-14 rounded-xl object-cover shrink-0 border border-zinc-800"
                  />
                  <div className="flex-1 truncate">
                    <h4 className="text-xs font-bold text-white truncate">{preset.title}</h4>
                    <p className="text-[11px] text-zinc-400 truncate mt-0.5">{preset.headline}</p>
                    <div className="flex items-center gap-2 mt-1 text-[10px] text-[#f5d77f]">
                      <span>⏱ المدة: {preset.duration} ثوانٍ</span>
                      <span>·</span>
                      <span>{preset.soundTrack}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Custom Headline & Subline */}
            <div className="space-y-3 pt-3 border-t border-zinc-800/80">
              <div className="space-y-1">
                <label className="text-[11px] text-zinc-400">العنوان المتحرك الرئيسي:</label>
                <input
                  type="text"
                  value={headline}
                  onChange={(e) => setHeadline(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#d4af37]"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[11px] text-zinc-400">النص الفرعي / تفاصيل المناسبة:</label>
                <input
                  type="text"
                  value={subline}
                  onChange={(e) => setSubline(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#d4af37]"
                />
              </div>
            </div>

            {/* Motion Effect Selector */}
            <div className="space-y-2 pt-2 border-t border-zinc-800/80">
              <label className="text-xs font-bold text-zinc-200">التأثير البصري الحركي:</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'sparks', label: 'رذاذ الذهب المتطاير' },
                  { id: 'shimmer', label: 'لمعان ذهبي دوري' },
                  { id: 'zoom', label: 'تكبير سينمائي بطيء' },
                ].map((eff) => (
                  <button
                    key={eff.id}
                    type="button"
                    onClick={() => setMotionEffect(eff.id as any)}
                    className={`p-2 rounded-xl border text-xs font-semibold text-center transition-all ${
                      motionEffect === eff.id
                        ? 'bg-[#d4af37]/20 border-[#d4af37] text-[#f5d77f]'
                        : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-white'
                    }`}
                  >
                    {eff.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Duration slider */}
            <div className="space-y-2 pt-2 border-t border-zinc-800/80">
              <div className="flex justify-between text-xs text-zinc-300">
                <span>مدة الفيديو:</span>
                <span className="font-bold text-[#f5d77f] font-mono">{duration} ثوانٍ</span>
              </div>
              <input
                type="range"
                min={4}
                max={15}
                value={duration}
                onChange={(e) => setDuration(Number(e.target.value))}
                className="w-full accent-[#d4af37]"
              />
            </div>
          </div>
        </div>

        {/* Right Column: Live 9:16 Video Player Stage */}
        <div className="lg:col-span-6 flex flex-col items-center">
          <div className="w-full max-w-[340px] sm:max-w-[360px] rounded-3xl bg-zinc-950 border-4 border-zinc-800 shadow-2xl p-2 relative overflow-hidden flex flex-col items-center">
            {/* 9:16 Phone Screen Frame */}
            <div className="w-full aspect-[9/16] rounded-2xl overflow-hidden relative bg-black flex flex-col justify-between p-5 select-none">
              {/* Animated Background Image */}
              <div
                className={`absolute inset-0 bg-cover bg-center transition-transform duration-1000 ease-out ${
                  motionEffect === 'zoom' && isPlaying ? 'scale-110' : 'scale-100'
                }`}
                style={{ backgroundImage: `url(${selectedPreset.image})` }}
              />

              {/* Scrim Overlay for readability */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-black/70 pointer-events-none" />

              {/* Floating Golden Particles effect */}
              {motionEffect === 'sparks' && (
                <div className="absolute inset-0 pointer-events-none overflow-hidden">
                  {[...Array(12)].map((_, i) => (
                    <div
                      key={i}
                      className="absolute rounded-full bg-[#f5d77f] opacity-70 animate-pulse"
                      style={{
                        width: `${Math.random() * 6 + 2}px`,
                        height: `${Math.random() * 6 + 2}px`,
                        top: `${(Math.sin(currentTime + i) * 40 + 50)}%`,
                        left: `${(i * 9 + (currentTime * 10) % 90)}%`,
                        boxShadow: '0 0 8px #f5d77f',
                        transition: 'top 0.3s ease, left 0.3s ease',
                      }}
                    />
                  ))}
                </div>
              )}

              {/* Top Bar of Story */}
              <div className="relative z-10 flex items-center justify-between text-white text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-full bg-[#d4af37] flex items-center justify-center font-black text-[#09090b] text-[10px]">
                    ف
                  </div>
                  <div>
                    <span className="font-bold text-xs block leading-none">فخامة التصميم AI</span>
                    <span className="text-[9px] text-zinc-300">موشن ستوري · راعي رسمي</span>
                  </div>
                </div>

                <button
                  onClick={() => {
                    setAudioEnabled(!audioEnabled);
                    if (!audioEnabled) playLuxuryChime();
                  }}
                  className="w-8 h-8 rounded-full bg-black/60 backdrop-blur-md flex items-center justify-center text-zinc-300 hover:text-white"
                  title="تشغيل الصوت الفاخر"
                >
                  {audioEnabled ? (
                    <Volume2 className="w-4 h-4 text-[#f5d77f]" />
                  ) : (
                    <VolumeX className="w-4 h-4" />
                  )}
                </button>
              </div>

              {/* Center Animated Typography */}
              <div className="relative z-10 my-auto text-center space-y-3 px-2">
                <div className="inline-block p-1 px-3 rounded-full bg-black/60 backdrop-blur-md border border-[#d4af37]/40 text-[10px] text-[#f5d77f] font-bold">
                  ✨ إصدار ملكي حصري
                </div>

                <h2
                  className={`text-xl sm:text-2xl font-black text-white leading-snug drop-shadow-lg transition-all duration-500 font-amiri ${
                    motionEffect === 'shimmer' ? 'text-gold-gradient' : ''
                  }`}
                >
                  {headline}
                </h2>

                <p className="text-xs text-zinc-200 drop-shadow font-cairo leading-relaxed max-w-xs mx-auto">
                  {subline}
                </p>
              </div>

              {/* Bottom CTA & Story progress */}
              <div className="relative z-10 space-y-2">
                {/* Story progress bar */}
                <div className="w-full bg-white/20 h-1 rounded-full overflow-hidden">
                  <div
                    className="bg-[#f5d77f] h-full transition-all duration-100 ease-linear"
                    style={{ width: `${(currentTime / duration) * 100}%` }}
                  />
                </div>

                <div className="w-full py-2 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#f5d77f] text-[#09090b] text-center font-bold text-xs shadow-lg shadow-black/50">
                  اسحب للأعلى للاكتشاف والمشاركة
                </div>
              </div>
            </div>

            {/* Playback Controls Bar */}
            <div className="w-full mt-3 p-2 bg-zinc-900 rounded-2xl flex items-center justify-between text-xs text-zinc-300">
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="w-9 h-9 rounded-xl bg-[#d4af37] text-zinc-950 flex items-center justify-center font-bold"
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
              </button>

              <span className="font-mono text-xs">
                {currentTime.toFixed(1)}s / {duration}s
              </span>

              <button
                onClick={() => {
                  setCurrentTime(0);
                  setIsPlaying(true);
                }}
                className="p-2 hover:text-white"
                title="إعادة التشغيل"
              >
                <RotateCcw className="w-4 h-4" />
              </button>

              <button
                onClick={() => onOpenInEditor(selectedPreset.image, selectedPreset.title)}
                className="px-2.5 py-1.5 rounded-lg bg-zinc-800 text-[11px] font-semibold text-[#f5d77f] hover:bg-zinc-700 flex items-center gap-1"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>فتح بالمحرر</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
