import React, { useState } from 'react';
import {
  PenTool,
  CheckCheck,
  Copy,
  Sparkles,
  ArrowRight,
  Edit3,
  Crown,
  Send,
  MessageSquare,
  Wand2,
  FileCheck
} from 'lucide-react';

interface AiCopywriterProps {
  onSendToEditor: (text: string) => void;
}

export const AiCopywriter: React.FC<AiCopywriterProps> = ({ onSendToEditor }) => {
  const [activeType, setActiveType] = useState<'ad' | 'greeting' | 'wedding' | 'proofread'>('ad');
  const [topic, setTopic] = useState('عطر شرقي بالعود الملكي والمسك الأسود');
  const [tone, setTone] = useState('ملكي فاخر وشاعري');
  const [audience, setAudience] = useState('عشاق الفخامة والذوق الرفيع في الخليج والوطن العربي');
  const [proofreadText, setProofreadText] = useState('يسرنا دعوتكم لحضور حفل زفاف ابننا الغالي ونرجو منكم الحضور لتشريفنا هدا المساء');
  const [isLoading, setIsLoading] = useState(false);
  const [generatedResult, setGeneratedResult] = useState<string>(
    `💎 الخيار الأول (فخامة حصرية):
«الفخامة ليست مجرد اختيار، بل أسلوب حياة استثنائي. استمتع بنفحات العود الملكي الممزوج بأندر قطرات المسك الأسود لتصنع هيبتك الخاصة في كل مكان.»

💎 الخيار الثاني (تسويقي تفاعلي):
«عطرك هو بصمتك التي تسبق حضورك وتبقى بعد غيابك. اكتشف مجموعة النخبة الجديدة بخصم 30% لفترة محدودة. اطلبه الآن قبل نفاد الإصدار المحدود!»`
  );
  const [copied, setCopied] = useState(false);

  const tones = [
    { id: 'ملكي فاخر وشاعري', label: 'ملكي فاخر وشاعري' },
    { id: 'تسويقي مقنع وجذاب', label: 'تسويقي مقنع وجذاب' },
    { id: 'رسمي رفيع المستوى', label: 'رسمي رفيع المستوى' },
    { id: 'دافئ وودي ومؤثر', label: 'عائلي دافئ ومؤثر' },
  ];

  const handleGenerate = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/ai/copywriter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: activeType,
          topic,
          tone,
          audience,
          inputProofread: proofreadText,
        }),
      });
      const data = await res.json();
      if (data.text) {
        setGeneratedResult(data.text);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedResult);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6 pb-12 animate-fade-in max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-800 pb-4">
        <div>
          <h1 className="text-2xl font-black text-white flex items-center gap-2">
            <PenTool className="w-6 h-6 text-[#f5d77f]" />
            المساعد الذكي لكتابة النصوص والتدقيق اللغوي
          </h1>
          <p className="text-xs text-zinc-400 mt-1">
            صياغة إعلانات تسويقية راقية، دعوات زفاف ملكية، وتدقيق لغوي عربي فوري
          </p>
        </div>

        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#d4af37]/15 border border-[#d4af37]/30 text-xs text-[#f5d77f] font-bold">
          <Sparkles className="w-3.5 h-3.5" />
          <span>ذكاء اصطناعي عربي متخصص</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {[
          { id: 'ad', label: 'إعلانات تسويقية فاخرة', icon: Wand2 },
          { id: 'greeting', label: 'تهاني ومناسبات وأعياد', icon: MessageSquare },
          { id: 'wedding', label: 'دعوات زفاف وملكة', icon: Crown },
          { id: 'proofread', label: 'تدقيق إملائي ونحوي', icon: FileCheck },
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => {
                setActiveType(tab.id as any);
                if (tab.id === 'wedding') {
                  setTopic('حفل زفاف سارة وخالد في قاعة الريتز');
                } else if (tab.id === 'greeting') {
                  setTopic('تهنئة بمناسبة عيد الأضحى المبارك للأهل والأصدقاء');
                } else if (tab.id === 'ad') {
                  setTopic('عطر شرقي بالعود الملكي والمسك الأسود');
                }
              }}
              className={`p-3 rounded-2xl border text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                activeType === tab.id
                  ? 'bg-gradient-to-r from-[#d4af37] to-[#f5d77f] text-[#09090b] border-[#d4af37] shadow-lg shadow-[#d4af37]/20'
                  : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-700'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Input Configuration Panel */}
        <div className="lg:col-span-5 space-y-4">
          <div className="rounded-2xl bg-zinc-900/90 border border-zinc-800 p-5 space-y-4 shadow-xl">
            {activeType === 'proofread' ? (
              <div className="space-y-2">
                <label className="text-xs font-bold text-white flex items-center gap-1.5">
                  <FileCheck className="w-4 h-4 text-[#f5d77f]" />
                  النص المراد تدقيقه وتصحيحه إملائياً ونحوياً:
                </label>
                <textarea
                  value={proofreadText}
                  onChange={(e) => setProofreadText(e.target.value)}
                  rows={6}
                  placeholder="الصق نصك هنا للتدقيق اللغوي وتصحيح الهمزات والتراكيب..."
                  className="w-full bg-zinc-950 border border-zinc-800 focus:border-[#d4af37] rounded-xl p-3 text-sm text-white focus:outline-none leading-relaxed"
                />
              </div>
            ) : (
              <>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-[#f5d77f]" />
                    موضوع المحتوى أو المنتج:
                  </label>
                  <textarea
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    rows={3}
                    placeholder="اكتب اسم المنتج أو فكرة المناسبة بالتفصيل..."
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-[#d4af37] rounded-xl p-3 text-sm text-white focus:outline-none leading-relaxed"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-white">نبرة الصياغة المطلوبة:</label>
                  <div className="grid grid-cols-2 gap-2">
                    {tones.map((t) => (
                      <button
                        key={t.id}
                        type="button"
                        onClick={() => setTone(t.id)}
                        className={`p-2.5 rounded-xl border text-xs font-semibold text-center transition-all ${
                          tone === t.id
                            ? 'bg-[#d4af37]/20 border-[#d4af37] text-[#f5d77f]'
                            : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-white'
                        }`}
                      >
                        {t.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-white">الجمهور المستهدف:</label>
                  <input
                    type="text"
                    value={audience}
                    onChange={(e) => setAudience(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-[#d4af37] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                  />
                </div>
              </>
            )}

            <button
              type="button"
              onClick={handleGenerate}
              disabled={isLoading}
              className="w-full h-12 rounded-xl bg-gradient-to-r from-[#d4af37] via-[#f5d77f] to-[#d4af37] text-[#09090b] font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-[#d4af37]/20 hover:opacity-95 active:scale-[0.99] transition-all cursor-pointer disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <Sparkles className="w-4 h-4 animate-spin" />
                  <span>جاري الصياغة الملكية...</span>
                </>
              ) : (
                <>
                  <PenTool className="w-4 h-4" />
                  <span>
                    {activeType === 'proofread' ? 'تدقيق النص الآن' : 'توليد النصوص بالذكاء الاصطناعي'}
                  </span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Results Output Panel */}
        <div className="lg:col-span-7 space-y-4">
          <div className="rounded-3xl bg-zinc-900/90 border border-zinc-800 p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <span className="text-xs font-bold text-white flex items-center gap-2">
                <Crown className="w-4 h-4 text-[#f5d77f]" />
                النتيجة المصاغة بواسطة فخامة AI
              </span>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopy}
                  className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  {copied ? (
                    <>
                      <CheckCheck className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400">تم النسخ</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-zinc-400" />
                      <span>نسخ النص</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Display formatted response */}
            <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800/80 min-h-[260px] text-zinc-100 text-sm leading-relaxed whitespace-pre-wrap font-sans">
              {generatedResult}
            </div>

            {/* Send to Editor Button */}
            <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-zinc-800">
              <span className="text-xs text-zinc-400">
                أعجبك النص؟ يمكنك إرساله مباشرة إلى محرر التصاميم كطبقة نصية
              </span>

              <button
                type="button"
                onClick={() => {
                  // extract first line or short summary
                  const firstLines = generatedResult
                    .split('\n')
                    .filter((l) => l.trim().startsWith('«') || l.length > 10)[0] || generatedResult.slice(0, 60);
                  const cleanText = firstLines.replace(/[«»💎✨]/g, '').trim();
                  onSendToEditor(cleanText);
                }}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#f5d77f] text-[#09090b] font-bold text-xs flex items-center justify-center gap-2 shadow-md shadow-[#d4af37]/20 hover:opacity-95"
              >
                <Edit3 className="w-4 h-4" />
                <span>إرسال هذا النص إلى المحرر</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
